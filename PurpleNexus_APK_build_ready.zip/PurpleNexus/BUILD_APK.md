# PurpleNexus - compilación APK

Este proyecto ya es una aplicación Android nativa (Kotlin + Jetpack Compose).

## Compilar automáticamente
1. Sube el contenido de este ZIP a un repositorio de GitHub.
2. Abre la pestaña **Actions**.
3. Ejecuta **Build PurpleNexus APK** con **Run workflow** (o haz push a `main`/`master`).
4. Cuando termine, abre la ejecución y descarga el artefacto **PurpleNexus-APKs**.
5. Dentro encontrarás los APK debug y release.

El APK release de este proyecto usa la firma debug configurada en `app/build.gradle.kts`,
por lo que sirve para instalar y probar, pero no es una firma de publicación para Play Store.

## Compilación local
Abre la carpeta `PurpleNexus` en Android Studio y espera a que sincronice Gradle.
Luego ejecuta `:app:assembleDebug` o `:app:assembleRelease`.
