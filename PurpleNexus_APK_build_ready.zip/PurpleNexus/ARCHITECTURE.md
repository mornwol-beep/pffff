# PURPLE NEXUS — Arquitectura

Paquete base: com.purplenexus.launcher

| Carpeta | Contenido |
|---|---|
| data/ | AppRepository (apps, categorías, lanzamiento animado), Prefs (DataStore: dock, carpeta, recientes, ajustes), System (batería, memoria), MusicBridge (MediaSession/MediaController real), NexusNotificationListener (permiso de acceso a sesiones), Lyrics (LRC + LRCLIB + caché + importación .lrc) |
| theme/ | Paleta, 5 estilos (StylePreset), perfiles LOW/MEDIUM/ULTRA, NexusSettings, LocalSettings |
| effects/ | FxEngine/ParticleField (partículas + ondas al tocar), AmbientBackground (niebla, cristales, olas, líneas), Ornaments |
| ui/ | HomeScreen (2 páginas), GlowClock, Widgets, MusicPanel, LyricsOverlay (letras sin fondo), Folder, AppDrawer, SettingsPanel, Welcome, GlassKit |

Fases: 1-2 base (hecho) · 3 rediseño visual (hecho) · 4 música+letras (implementado, sin compilar aún) · 5 Game Boost/Purple Lab · 6 pruebas.
