package com.purplenexus.launcher.data

import android.service.notification.NotificationListenerService

/**
 * Servicio vacío a propósito: Android solo permite a una app consultar las sesiones multimedia de otras apps
 * (MediaSessionManager.getActiveSessions) si tiene un NotificationListenerService habilitado por el usuario.
 * Este servicio NO lee, guarda ni reenvía ninguna notificación.
 */
class NexusNotificationListener : NotificationListenerService() {
    override fun onListenerConnected() {
        super.onListenerConnected()
        MusicBridge.refresh()
    }
}
