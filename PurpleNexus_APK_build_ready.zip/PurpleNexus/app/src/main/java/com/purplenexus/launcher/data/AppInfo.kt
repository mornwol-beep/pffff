package com.purplenexus.launcher.data

import androidx.compose.ui.graphics.ImageBitmap

data class AppInfo(
    val label: String,
    val pkg: String,
    val activity: String,
    val icon: ImageBitmap,
    val category: Int,
)
