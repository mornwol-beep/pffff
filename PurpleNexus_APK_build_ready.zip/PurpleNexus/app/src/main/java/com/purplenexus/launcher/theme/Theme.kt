package com.purplenexus.launcher.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp

object Nexus {
    val DeepPurple = Color(0xFF170D29)
    val Violet = Color(0xFF7138C8)
    val Lavender = Color(0xFFB99AFF)
    val Bright = Color(0xFFA855F7)
    val Night = Color(0xFF17152D)
    val White = Color(0xFFF4EEFF)

    val Pill = RoundedCornerShape(28.dp)
    val Card = RoundedCornerShape(24.dp)
    val Tile = RoundedCornerShape(18.dp)
}

@Immutable
data class Palette(
    val bgTop: Color,
    val bgMid: Color,
    val bgBottom: Color,
    val accent: Color,
    val lavender: Color,
    val cyan: Color,
    val pearl: Color = Color(0xFFF4EEFF),
)

object Kind {
    const val STAR = 0
    const val DUST = 1
    const val RAIN = 2
    const val BUBBLE = 3
}

enum class StylePreset(val label: String, val palette: Palette, val kinds: IntArray) {
    FURINA_HYDRO(
        "Furina Hydro",
        Palette(Color(0xFF0E0B2C), Color(0xFF1B2F7A), Color(0xFF244A9E), Color(0xFF7C8CFF), Color(0xFFBCC8FF), Color(0xFF5FE3F5)),
        intArrayOf(Kind.BUBBLE, Kind.STAR, Kind.DUST),
    ),
    PURPLE_GALAXY(
        "Purple Galaxy",
        Palette(Color(0xFF0A0520), Color(0xFF1D0F4A), Color(0xFF3A1A7A), Color(0xFFA855F7), Color(0xFFB99AFF), Color(0xFF7DD3FC)),
        intArrayOf(Kind.STAR, Kind.DUST, Kind.STAR),
    ),
    VIOLET_RAIN(
        "Violet Rain",
        Palette(Color(0xFF120824), Color(0xFF1E1140), Color(0xFF3A2380), Color(0xFF8B5CF6), Color(0xFFC4B5FD), Color(0xFF67E8F9)),
        intArrayOf(Kind.RAIN, Kind.DUST, Kind.RAIN),
    ),
    CRYSTAL_DREAM(
        "Crystal Dream",
        Palette(Color(0xFF1B1040), Color(0xFF3A2380), Color(0xFF6D3FC0), Color(0xFFC084FC), Color(0xFFE9D8FF), Color(0xFF67E8F9)),
        intArrayOf(Kind.DUST, Kind.STAR, Kind.BUBBLE),
    ),
    MIDNIGHT_FANTASY(
        "Midnight Fantasy",
        Palette(Color(0xFF07061A), Color(0xFF17152D), Color(0xFF2D1B5E), Color(0xFF7138C8), Color(0xFFB99AFF), Color(0xFF38BDF8)),
        intArrayOf(Kind.STAR, Kind.STAR, Kind.DUST),
    ),
}

enum class GraphicsProfile(
    val label: String,
    val particleBase: Int,
    val frameMs: Long,
    val animatedAmbient: Boolean,
) {
    LOW("Bajo", 14, 33L, false),
    MEDIUM("Medio", 36, 16L, true),
    ULTRA("Ultra", 80, 0L, true),
}

enum class NexusFont(val label: String, val family: FontFamily) {
    SERIF("Elegante", FontFamily.Serif),
    SANS("Moderna", FontFamily.SansSerif),
    MONO("Técnica", FontFamily.Monospace),
}

data class NexusSettings(
    val style: StylePreset = StylePreset.FURINA_HYDRO,
    val profile: GraphicsProfile = GraphicsProfile.MEDIUM,
    val effects: Boolean = true,
    val particles: Float = 0.7f,
    val glass: Float = 0.7f,
    val glow: Float = 0.7f,
    val touchFx: Boolean = true,
    val glassIcons: Boolean = true,
    val decorations: Boolean = true,
    val sounds: Boolean = false,
    val font: NexusFont = NexusFont.SERIF,
    // Letras sincronizadas sobre el fondo (fase 4)
    val lyrics: Boolean = true,
    val lyricsOnline: Boolean = true,
    val lyricsSize: Float = 0.5f,   // 0..1 → 14..32 sp
    val lyricsY: Float = 0.5f,      // 0 = arriba, 1 = abajo
)

val NexusSettings.palette: Palette get() = style.palette

val LocalSettings = staticCompositionLocalOf { NexusSettings() }

private val Scheme = darkColorScheme(
    primary = Nexus.Bright,
    onPrimary = Nexus.White,
    secondary = Nexus.Lavender,
    background = Nexus.DeepPurple,
    surface = Nexus.Night,
    onSurface = Nexus.White,
    onBackground = Nexus.White,
)

@Composable
fun NexusTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = Scheme, content = content)
}
