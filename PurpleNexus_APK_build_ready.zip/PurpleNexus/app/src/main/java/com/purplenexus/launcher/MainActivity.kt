package com.purplenexus.launcher

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.lifecycleScope
import com.purplenexus.launcher.data.AppRepository
import com.purplenexus.launcher.data.MusicBridge
import com.purplenexus.launcher.data.Prefs
import com.purplenexus.launcher.theme.NexusSettings
import com.purplenexus.launcher.theme.NexusTheme
import com.purplenexus.launcher.ui.HomeScreen
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    private lateinit var repo: AppRepository
    private lateinit var prefs: Prefs
    private val homeTick = mutableIntStateOf(0)
    private val resumed = mutableStateOf(true)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        MusicBridge.init(applicationContext)
        repo = AppRepository(applicationContext)
        prefs = Prefs(applicationContext)
        setContent {
            val settings by prefs.settings.collectAsState(initial = null as NexusSettings?)
            NexusTheme {
                HomeScreen(repo, prefs, settings, homeTick.intValue, resumed.value)
            }
        }
        lifecycleScope.launch { repo.load() }
    }

    // El enlace con las sesiones multimedia solo está activo mientras el launcher es visible.
    override fun onStart() { super.onStart(); repo.startWatching(); MusicBridge.start() }
    override fun onStop() { super.onStop(); repo.stopWatching(); MusicBridge.stop() }

    // Las partículas solo corren mientras el launcher es visible (ahorro de batería).
    override fun onResume() { super.onResume(); resumed.value = true; MusicBridge.refresh() }
    override fun onPause() { super.onPause(); resumed.value = false }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (intent.action == Intent.ACTION_MAIN && intent.hasCategory(Intent.CATEGORY_HOME)) {
            homeTick.intValue++
        }
    }
}
