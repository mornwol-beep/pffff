package com.purplenexus.launcher.data

import android.app.ActivityOptions
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.content.ContextCompat
import androidx.core.graphics.drawable.toBitmap
import com.purplenexus.launcher.R
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class AppRepository(private val ctx: Context) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val _apps = MutableStateFlow<List<AppInfo>>(emptyList())
    val apps: StateFlow<List<AppInfo>> = _apps.asStateFlow()

    suspend fun load() = withContext(Dispatchers.IO) {
        val pm = ctx.packageManager
        val query = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        _apps.value = pm.queryIntentActivities(query, 0)
            .filter { it.activityInfo.packageName != ctx.packageName }
            .map {
                AppInfo(
                    label = it.loadLabel(pm).toString(),
                    pkg = it.activityInfo.packageName,
                    activity = it.activityInfo.name,
                    icon = it.loadIcon(pm).toBitmap(128, 128).asImageBitmap(),
                    category = it.activityInfo.applicationInfo.category,
                )
            }
            .sortedBy { it.label.lowercase() }
    }

    fun launch(app: AppInfo, animate: Boolean = true) {
        val intent = Intent(Intent.ACTION_MAIN)
            .addCategory(Intent.CATEGORY_LAUNCHER)
            .setComponent(ComponentName(app.pkg, app.activity))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        val options = if (animate) {
            ActivityOptions.makeCustomAnimation(ctx, R.anim.nexus_launch_enter, R.anim.nexus_launch_exit).toBundle()
        } else null
        runCatching { ctx.startActivity(intent, options) }
    }

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) { scope.launch { load() } }
    }
    private var watching = false

    fun startWatching() {
        if (watching) return
        val f = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED)
            addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(Intent.ACTION_PACKAGE_REPLACED)
            addDataScheme("package")
        }
        ContextCompat.registerReceiver(ctx, receiver, f, ContextCompat.RECEIVER_EXPORTED)
        watching = true
    }

    fun stopWatching() {
        if (!watching) return
        ctx.unregisterReceiver(receiver)
        watching = false
    }
}
