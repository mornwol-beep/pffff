package com.purplenexus.launcher.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.purplenexus.launcher.theme.GraphicsProfile
import com.purplenexus.launcher.theme.LocalSettings
import com.purplenexus.launcher.theme.Nexus
import com.purplenexus.launcher.theme.NexusFont
import com.purplenexus.launcher.theme.NexusSettings
import com.purplenexus.launcher.theme.StylePreset
import com.purplenexus.launcher.theme.palette

/**
 * Panel de personalización. [onChange] recibe los nuevos ajustes y si deben guardarse ya
 * (los deslizadores guardan solo al soltar). Los cambios se ven en vivo sobre el fondo.
 */
@Composable
fun SettingsPanel(
    s: NexusSettings,
    onChange: (NexusSettings, Boolean) -> Unit,
    onReset: () -> Unit,
    onClose: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val p = s.palette
    val shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp)
    Column(
        modifier
            .background(p.bgTop.copy(alpha = 0.88f), shape)
            .glass(shape, ornate = true)
            .tap { }
            .padding(horizontal = 18.dp),
    ) {
        Row(Modifier.fillMaxWidth().padding(vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Personalización", color = Nexus.White, fontSize = 20.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f))
            Box(Modifier.tap(onClose).padding(6.dp)) { GlyphIcon(Glyph.CLOSE, p.lavender, 22.dp) }
        }
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).navigationBarsPadding()) {
            Section("Estilo visual")
            ChipRow(StylePreset.entries, s.style, { it.label }) { onChange(s.copy(style = it), true) }

            Section("Rendimiento gráfico")
            ChipRow(GraphicsProfile.entries, s.profile, { it.label }) { onChange(s.copy(profile = it), true) }
            ToggleRow("Efectos visuales", "Apágalos para ahorrar batería y RAM", s.effects) { onChange(s.copy(effects = it), true) }

            Section("Intensidad")
            SliderRow("Partículas", s.particles, { onChange(s.copy(particles = it), false) }) { onChange(s, true) }
            SliderRow("Transparencia del cristal", s.glass, { onChange(s.copy(glass = it), false) }) { onChange(s, true) }
            SliderRow("Iluminación", s.glow, { onChange(s.copy(glow = it), false) }) { onChange(s, true) }

            Section("Interfaz")
            ToggleRow("Partículas y ondas al tocar", "Reaccionan a tu dedo", s.touchFx) { onChange(s.copy(touchFx = it), true) }
            ToggleRow("Marcos de cristal en iconos", "Desactívalo para ver los iconos originales", s.glassIcons) { onChange(s.copy(glassIcons = it), true) }
            ToggleRow("Decoraciones", "Cristales, líneas luminosas y ornamentos", s.decorations) { onChange(s.copy(decorations = it), true) }
            ToggleRow("Sonidos al tocar", "Usa el sonido de toque del sistema", s.sounds) { onChange(s.copy(sounds = it), true) }

            Section("Letras sobre el fondo")
            ToggleRow("Letras sincronizadas", "Sin tarjeta, sobre el fondo del launcher; nunca sobre otras apps", s.lyrics) { onChange(s.copy(lyrics = it), true) }
            ToggleRow("Buscar letras en internet", "Envía título, artista y duración a lrclib.net. Desactívalo para usar solo archivos .lrc importados", s.lyricsOnline) { onChange(s.copy(lyricsOnline = it), true) }
            SliderRow("Tamaño del texto", s.lyricsSize, { onChange(s.copy(lyricsSize = it), false) }) { onChange(s, true) }
            SliderRow("Posición vertical", s.lyricsY, { onChange(s.copy(lyricsY = it), false) }) { onChange(s, true) }

            Section("Tipografía del reloj")
            ChipRow(NexusFont.entries, s.font, { it.label }) { onChange(s.copy(font = it), true) }

            Spacer(Modifier.height(18.dp))
            Box(
                Modifier
                    .fillMaxWidth()
                    .border(1.dp, p.lavender.copy(alpha = 0.5f), Nexus.Pill)
                    .tap(onReset)
                    .padding(vertical = 12.dp),
                contentAlignment = Alignment.Center,
            ) { Text("Restaurar valores por defecto", color = p.lavender, fontSize = 14.sp) }
            Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable
private fun Section(title: String) {
    val p = LocalSettings.current.palette
    Text(
        title.uppercase(), color = p.lavender, fontSize = 11.sp, letterSpacing = 2.sp,
        modifier = Modifier.padding(top = 18.dp, bottom = 8.dp),
    )
}

@Composable
private fun <T> ChipRow(items: List<T>, selected: T, label: (T) -> String, onSelect: (T) -> Unit) {
    val p = LocalSettings.current.palette
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        items.forEach { item ->
            val sel = item == selected
            Box(
                Modifier
                    .background(if (sel) p.accent.copy(alpha = 0.35f) else Color.White.copy(alpha = 0.05f), Nexus.Pill)
                    .border(1.dp, p.lavender.copy(alpha = if (sel) 0.9f else 0.25f), Nexus.Pill)
                    .tap { onSelect(item) }
                    .padding(horizontal = 16.dp, vertical = 9.dp),
            ) { Text(label(item), color = if (sel) Nexus.White else p.lavender, fontSize = 13.sp) }
        }
    }
}

@Composable
private fun ToggleRow(title: String, sub: String, checked: Boolean, onChecked: (Boolean) -> Unit) {
    val p = LocalSettings.current.palette
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, color = Nexus.White, fontSize = 15.sp)
            Text(sub, color = p.lavender.copy(alpha = 0.75f), fontSize = 12.sp)
        }
        Switch(
            checked = checked, onCheckedChange = onChecked,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Nexus.White, checkedTrackColor = p.accent,
                uncheckedThumbColor = p.lavender, uncheckedTrackColor = Color.White.copy(alpha = 0.1f),
            ),
        )
    }
}

@Composable
private fun SliderRow(title: String, value: Float, onValue: (Float) -> Unit, onFinished: () -> Unit) {
    val p = LocalSettings.current.palette
    Column(Modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(title, color = Nexus.White, fontSize = 14.sp)
            Text("${(value * 100).toInt()}%", color = p.lavender, fontSize = 13.sp, textAlign = TextAlign.End)
        }
        Slider(
            value = value, onValueChange = onValue, onValueChangeFinished = onFinished,
            colors = SliderDefaults.colors(
                thumbColor = p.pearl, activeTrackColor = p.accent, inactiveTrackColor = Color.White.copy(alpha = 0.12f),
            ),
        )
    }
}
