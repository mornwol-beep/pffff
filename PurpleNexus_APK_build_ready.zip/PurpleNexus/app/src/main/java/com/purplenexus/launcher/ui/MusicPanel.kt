package com.purplenexus.launcher.ui

import android.content.Intent
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.purplenexus.launcher.data.LyricsRepository
import com.purplenexus.launcher.data.MusicBridge
import kotlinx.coroutines.launch
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.purplenexus.launcher.data.MusicState
import com.purplenexus.launcher.theme.LocalSettings
import com.purplenexus.launcher.theme.Nexus
import com.purplenexus.launcher.theme.palette
import kotlin.math.PI
import kotlin.math.sin

private fun fmt(ms: Long): String {
    val t = (ms / 1000).coerceAtLeast(0)
    return "%d:%02d".format(t / 60, t % 60)
}

/**
 * Reproductor conectado a la sesión multimedia activa (MusicBridge). Con [state] nulo muestra "Sin reproducción".
 * Los controles actúan sobre la app que está sonando; tocar la barra salta a esa posición si la app lo permite.
 * La animación de ondas es decorativa: reacciona al estado reproduciendo/pausado, no al audio real
 * (Android no deja analizar el audio de otras apps sin permiso de grabación).
 */
@Composable
fun MusicPanel(
    state: MusicState?,
    modifier: Modifier = Modifier,
    onPrev: () -> Unit = MusicBridge::prev,
    onToggle: () -> Unit = MusicBridge::toggle,
    onNext: () -> Unit = MusicBridge::next,
    onSeek: (Float) -> Unit = MusicBridge::seekToFraction,
    active: Boolean = true,
) {
    val s = LocalSettings.current
    val p = s.palette
    // Color dinámico: el dominante de la portada (calculado en MusicBridge); si no hay portada, el acento del estilo.
    val tint = state?.accent ?: p.accent
    val enabled = state != null
    val ctx = LocalContext.current
    val hasAccess by MusicBridge.access.collectAsState()
    val livePos by rememberLivePosition(state, active)
    val scope = rememberCoroutineScope()
    var importMsg by remember { mutableStateOf<String?>(null) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        val st = state
        if (uri != null && st != null) scope.launch {
            importMsg = if (LyricsRepository.importFor(ctx, st, uri)) "Letra importada" else "El archivo no tiene letra sincronizada (.lrc)"
        }
    }

    Column(
        modifier
            .glass(Nexus.Card, ornate = true, sweep = true)
            .drawBehind {
                drawRect(
                    Brush.radialGradient(
                        listOf(tint.copy(alpha = 0.35f * s.glow), Color.Transparent),
                        center = Offset(size.width / 2, size.height * 0.25f), radius = size.width,
                    ),
                )
            }
            .padding(18.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text("REPRODUCTOR", color = p.lavender, fontSize = 10.sp, letterSpacing = 2.sp, modifier = Modifier.align(Alignment.Start))
        Spacer(Modifier.height(12.dp))

        val coverShape = RoundedCornerShape(22.dp)
        Box(
            Modifier
                .size(176.dp)
                .background(Brush.linearGradient(listOf(p.accent.copy(alpha = 0.6f), p.bgMid)), coverShape)
                .border(1.5.dp, Brush.linearGradient(listOf(p.lavender, p.cyan.copy(alpha = 0.5f), p.accent)), coverShape),
            contentAlignment = Alignment.Center,
        ) {
            if (state?.cover != null) {
                Image(state.cover, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            } else {
                GlyphIcon(Glyph.STAR, p.pearl.copy(alpha = 0.85f), 64.dp)
            }
        }

        Spacer(Modifier.height(14.dp))
        Text(
            state?.title ?: "Sin reproducción", color = Nexus.White, fontSize = 20.sp, fontWeight = FontWeight.SemiBold,
            maxLines = 1, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center,
        )
        Text(
            state?.artist?.ifBlank { state?.album ?: "" } ?: if (hasAccess) "Reproduce música en tu app favorita" else "Falta conceder acceso a notificaciones", color = p.lavender, fontSize = 13.sp,
            maxLines = 1, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center,
        )

        Spacer(Modifier.height(10.dp))
        Equalizer(playing = state?.playing == true, tint = tint)

        Spacer(Modifier.height(8.dp))
        val frac = if (state != null && state.durationMs > 0) livePos.toFloat() / state.durationMs else 0f
        var barW by remember { mutableStateOf(1) }
        Box(
            Modifier
                .fillMaxWidth()
                .height(26.dp)
                .onSizeChanged { barW = it.width.coerceAtLeast(1) }
                .pointerInput(enabled) { if (enabled) detectTapGestures { o -> onSeek(o.x / barW) } },
            contentAlignment = Alignment.Center,
        ) { GlowBar(frac) }
        Row(Modifier.fillMaxWidth().padding(top = 4.dp), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(fmt(livePos), color = Nexus.White.copy(alpha = 0.7f), fontSize = 11.sp)
            Text(fmt(state?.durationMs ?: 0), color = Nexus.White.copy(alpha = 0.7f), fontSize = 11.sp)
        }

        Spacer(Modifier.height(8.dp))
        Row(
            Modifier.alpha(if (enabled) 1f else 0.4f),
            horizontalArrangement = Arrangement.spacedBy(18.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            ControlButton(Glyph.PREV, 46, enabled, onPrev)
            ControlButton(if (state?.playing == true) Glyph.PAUSE else Glyph.PLAY, 62, enabled, onToggle, emphasized = true)
            ControlButton(Glyph.NEXT, 46, enabled, onNext)
        }

        Spacer(Modifier.height(12.dp))
        if (!hasAccess) {
            Text(
                "Para leer la canción actual, Android requiere dar acceso a notificaciones a Purple Nexus. " +
                    "No se lee ninguna notificación: solo la sesión de reproducción.",
                color = p.lavender.copy(alpha = 0.85f), fontSize = 11.sp, textAlign = TextAlign.Center,
            )
            Spacer(Modifier.height(8.dp))
            PillButton("Conceder acceso") {
                ctx.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }
        } else if (state != null) {
            PillButton("Importar letra (.lrc)") { picker.launch(arrayOf("*/*")) }
            importMsg?.let {
                Spacer(Modifier.height(6.dp))
                Text(it, color = p.lavender, fontSize = 11.sp, textAlign = TextAlign.Center)
            }
        }
    }
}

@Composable
private fun PillButton(label: String, onClick: () -> Unit) {
    val p = LocalSettings.current.palette
    Box(
        Modifier
            .border(1.dp, p.lavender.copy(alpha = 0.6f), Nexus.Pill)
            .tap(onClick)
            .padding(horizontal = 18.dp, vertical = 8.dp),
    ) { Text(label, color = p.lavender, fontSize = 12.sp) }
}

@Composable
private fun ControlButton(glyph: Glyph, sizeDp: Int, enabled: Boolean, onClick: () -> Unit, emphasized: Boolean = false) {
    val p = LocalSettings.current.palette
    val tapSound = rememberTapSound()
    val bg = if (emphasized) Brush.linearGradient(listOf(p.accent, p.bgMid)) else Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.14f), p.bgMid.copy(alpha = 0.5f)))
    Box(
        Modifier
            .size(sizeDp.dp)
            .background(bg, CircleShape)
            .border(1.dp, Brush.linearGradient(listOf(p.lavender.copy(alpha = 0.8f), p.cyan.copy(alpha = 0.3f))), CircleShape)
            .tap { if (enabled) { tapSound(); onClick() } },
        contentAlignment = Alignment.Center,
    ) {
        GlyphIcon(glyph, Nexus.White, (sizeDp * 0.42f).dp)
    }
}

@Composable
private fun Equalizer(playing: Boolean, tint: Color) {
    val s = LocalSettings.current
    val p = s.palette
    val phase = rememberPhase(playing && s.effects, 1600)
    Canvas(Modifier.fillMaxWidth().height(36.dp)) {
        val n = 28
        val gap = 3.dp.toPx()
        val bw = (size.width - gap * (n - 1)) / n
        val t = phase.value
        for (i in 0 until n) {
            val env = 0.45f + 0.55f * sin(PI.toFloat() * i / (n - 1))
            val wave = if (playing) 0.5f + 0.5f * sin(2f * PI.toFloat() * (t * 2f + i * 0.13f)) else 0.1f
            val hh = (size.height * (0.1f + 0.9f * wave * env)).coerceAtLeast(3.dp.toPx())
            drawRoundRect(
                Brush.verticalGradient(listOf(tint, p.accent), startY = size.height - hh, endY = size.height),
                topLeft = Offset(i * (bw + gap), size.height - hh), size = Size(bw, hh), cornerRadius = CornerRadius(bw / 2),
            )
        }
    }
}
