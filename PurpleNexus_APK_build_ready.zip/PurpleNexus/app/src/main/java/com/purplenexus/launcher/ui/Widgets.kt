package com.purplenexus.launcher.ui

import android.os.Build
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.purplenexus.launcher.data.rememberBattery
import com.purplenexus.launcher.data.rememberMemory
import com.purplenexus.launcher.theme.LocalSettings
import com.purplenexus.launcher.theme.Nexus
import com.purplenexus.launcher.theme.palette
import java.time.LocalDate
import java.time.YearMonth
import java.time.format.TextStyle as JTextStyle
import java.util.Locale

@Composable
fun WidgetCard(modifier: Modifier = Modifier, title: String, content: @Composable ColumnScope.() -> Unit) {
    val p = LocalSettings.current.palette
    Column(modifier.glass(Nexus.Card, ornate = true, sweep = true).padding(14.dp)) {
        Text(title.uppercase(), color = p.lavender, fontSize = 10.sp, letterSpacing = 2.sp)
        Spacer(Modifier.height(8.dp))
        content()
    }
}

@Composable
fun BatteryWidget(modifier: Modifier = Modifier) {
    val b by rememberBattery()
    val p = LocalSettings.current.palette
    val frac by animateFloatAsState(if (b.level < 0) 0f else b.level / 100f, tween(800), label = "bat")
    val col = when {
        b.charging -> p.cyan
        b.level in 0..19 -> Color(0xFFFF7A9C)
        else -> p.lavender
    }
    WidgetCard(modifier, "Batería") {
        Box(Modifier.size(78.dp).align(Alignment.CenterHorizontally), contentAlignment = Alignment.Center) {
            Canvas(Modifier.fillMaxSize()) {
                val sw = 7.dp.toPx()
                val tl = Offset(sw / 2, sw / 2)
                val sz = Size(size.width - sw, size.height - sw)
                drawArc(Color.White.copy(alpha = 0.1f), 135f, 270f, false, tl, sz, style = Stroke(sw, cap = StrokeCap.Round))
                if (frac > 0f) {
                    drawArc(col.copy(alpha = 0.25f), 135f, 270f * frac, false, tl, sz, style = Stroke(sw * 1.9f, cap = StrokeCap.Round))
                    drawArc(col, 135f, 270f * frac, false, tl, sz, style = Stroke(sw, cap = StrokeCap.Round))
                }
            }
            Text(if (b.level < 0) "--" else "${b.level}%", color = Nexus.White, fontSize = 18.sp, fontWeight = FontWeight.Medium)
        }
        Spacer(Modifier.height(6.dp))
        Text(
            if (b.charging) "Cargando" else "En uso", color = Nexus.White, fontSize = 12.sp,
            textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth(),
        )
        if (b.tempC > 0f) {
            Text(
                String.format(Locale.US, "%.1f °C", b.tempC), color = p.lavender, fontSize = 11.sp,
                textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth(),
            )
        }
    }
}

@Composable
fun CalendarWidget(modifier: Modifier = Modifier) {
    val p = LocalSettings.current.palette
    val es = Locale("es", "ES")
    val today = LocalDate.now()
    val ym = YearMonth.from(today)
    val offset = ym.atDay(1).dayOfWeek.value - 1
    val days = ym.lengthOfMonth()
    val rows = (offset + days + 6) / 7
    val month = ym.month.getDisplayName(JTextStyle.FULL, es).replaceFirstChar { it.uppercase() }
    WidgetCard(modifier, "$month ${ym.year}") {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            listOf("L", "M", "X", "J", "V", "S", "D").forEach {
                Text(it, color = p.lavender.copy(alpha = 0.7f), fontSize = 10.sp, textAlign = TextAlign.Center, modifier = Modifier.width(20.dp))
            }
        }
        for (r in 0 until rows) {
            Row(Modifier.fillMaxWidth().padding(top = 3.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                for (c in 0..6) {
                    val day = r * 7 + c - offset + 1
                    val isToday = day == today.dayOfMonth
                    Box(
                        Modifier
                            .size(20.dp)
                            .background(if (isToday) p.accent.copy(alpha = 0.85f) else Color.Transparent, CircleShape),
                        contentAlignment = Alignment.Center,
                    ) {
                        if (day in 1..days) {
                            Text(day.toString(), color = Nexus.White, fontSize = 10.sp, fontWeight = if (isToday) FontWeight.Bold else FontWeight.Normal)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun DeviceWidget(modifier: Modifier = Modifier) {
    val mem by rememberMemory()
    val p = LocalSettings.current.palette
    val name = Build.MANUFACTURER.replaceFirstChar { it.uppercase() } + " " + Build.MODEL
    WidgetCard(modifier, "Dispositivo") {
        Text(name, color = Nexus.White, fontSize = 15.sp, fontWeight = FontWeight.Medium, maxLines = 1)
        Text("Android ${Build.VERSION.RELEASE}", color = p.lavender, fontSize = 12.sp)
        Spacer(Modifier.height(10.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("Memoria en uso", color = Nexus.White.copy(alpha = 0.8f), fontSize = 11.sp)
            Text(
                "${mem.usedPct}% · " + String.format(Locale.US, "%.1f GB", mem.totalGb),
                color = p.cyan, fontSize = 11.sp,
            )
        }
        Spacer(Modifier.height(6.dp))
        GlowBar(mem.usedPct / 100f)
    }
}
