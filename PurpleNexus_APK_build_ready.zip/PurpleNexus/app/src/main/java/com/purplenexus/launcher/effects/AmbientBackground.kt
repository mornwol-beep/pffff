package com.purplenexus.launcher.effects

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import com.purplenexus.launcher.theme.NexusSettings
import com.purplenexus.launcher.theme.Palette
import com.purplenexus.launcher.theme.palette
import com.purplenexus.launcher.ui.rememberPhase
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

private val TAU = (2.0 * PI).toFloat()

// cx (fracción del ancho), ancho dp, alto dp, inclinación dp, profundidad
private val LeftCrystals = arrayOf(
    floatArrayOf(0.06f, 44f, 150f, -10f, 1.0f),
    floatArrayOf(0.17f, 30f, 96f, 8f, 0.8f),
    floatArrayOf(-0.01f, 30f, 70f, -6f, 0.65f),
)
private val RightCrystals = arrayOf(
    floatArrayOf(0.94f, 44f, 140f, 10f, 1.0f),
    floatArrayOf(0.83f, 30f, 92f, -8f, 0.8f),
    floatArrayOf(1.02f, 30f, 66f, 6f, 0.65f),
)

@Composable
fun AmbientBackground(s: NexusSettings, parallax: () -> Float, modifier: Modifier = Modifier) {
    val p = s.palette
    val phase = rememberPhase(s.effects && s.profile.animatedAmbient, 24000)
    Canvas(modifier.fillMaxSize()) {
        val w = size.width
        val h = size.height
        drawRect(Brush.verticalGradient(listOf(p.bgTop, p.bgMid, p.bgBottom)))
        if (!s.effects) return@Canvas

        val t = phase.value
        val par = parallax()
        val glow = s.glow

        // Iluminación ambiental superior
        val lc = Offset(w * (0.5f + 0.18f * sin(TAU * t)), h * 0.16f)
        val lr = w * 0.95f
        drawCircle(
            Brush.radialGradient(listOf(p.accent.copy(alpha = 0.32f * glow), Color.Transparent), center = lc, radius = lr),
            radius = lr, center = lc,
        )

        // Niebla en capas
        for (k in 0..2) {
            val cx = w * (0.2f + 0.3f * k) + sin(TAU * (t + k * 0.31f)) * w * 0.12f + par * 30.dp.toPx() * (k + 1) * 0.4f
            val cy = h * (0.35f + 0.17f * k) + cos(TAU * (t + k * 0.17f)) * h * 0.04f
            val r = w * 0.75f
            val col = if (k == 1) p.cyan else p.lavender
            drawCircle(
                Brush.radialGradient(listOf(col.copy(alpha = 0.11f * glow), Color.Transparent), center = Offset(cx, cy), radius = r),
                radius = r, center = Offset(cx, cy),
            )
        }

        if (s.decorations) {
            // Líneas luminosas
            for (k in 0..2) {
                val sx = w * (0.05f + 0.12f * k) + sin(TAU * (t + k * 0.2f)) * w * 0.03f
                val start = Offset(sx, 0f)
                val end = Offset(sx + h * (0.35f + 0.1f * k), h * (0.6f + 0.1f * k))
                drawLine(
                    Brush.linearGradient(
                        colors = listOf(Color.Transparent, p.lavender.copy(alpha = 0.35f * glow), Color.Transparent),
                        start = start, end = end,
                    ),
                    start, end, strokeWidth = 1.dp.toPx(),
                )
            }
            // Cristales decorativos con parallax y flotación
            var idx = 0
            for (c in LeftCrystals + RightCrystals) {
                val cx = w * c[0] - par * 36.dp.toPx() * c[4]
                val baseY = h * 0.93f + sin(TAU * (t * 3f + idx * 0.3f)) * 4.dp.toPx()
                crystal(cx, baseY, c[1].dp.toPx(), c[2].dp.toPx(), c[3].dp.toPx(), p, (0.55f + 0.45f * glow) * c[4])
                idx++
            }
        }

        // Agua: tres olas translúcidas
        val steps = (w / 14.dp.toPx()).toInt().coerceAtLeast(8)
        for (layer in 0..2) {
            val y0 = h * (0.945f - layer * 0.022f)
            val amp = (5f + layer * 3f).dp.toPx()
            val phs = TAU * (t * (layer + 1) + layer * 0.33f)
            val path = Path()
            path.moveTo(0f, h)
            for (i in 0..steps) {
                val x = w * i / steps
                path.lineTo(x, y0 + amp * sin(x / w * TAU * (1.4f + layer * 0.6f) + phs + par * 1.2f))
            }
            path.lineTo(w, h)
            path.close()
            drawPath(
                path,
                Brush.verticalGradient(
                    listOf(p.cyan.copy(alpha = 0.16f * glow * (1f - layer * 0.2f)), p.accent.copy(alpha = 0.04f)),
                    startY = y0 - amp, endY = h,
                ),
            )
        }

        if (s.decorations) {
            cornerOrnaments(p.lavender.copy(alpha = 0.4f), 12.dp.toPx(), 30.dp.toPx())
        }
    }
}

private fun DrawScope.crystal(cx: Float, baseY: Float, wd: Float, ht: Float, tilt: Float, p: Palette, a: Float) {
    val path = Path().apply {
        moveTo(cx - wd / 2, baseY)
        lineTo(cx - wd / 2 + tilt, baseY - ht * 0.72f)
        lineTo(cx + tilt, baseY - ht)
        lineTo(cx + wd / 2 + tilt, baseY - ht * 0.72f)
        lineTo(cx + wd / 2, baseY)
        close()
    }
    drawPath(
        path,
        Brush.verticalGradient(
            listOf(p.lavender.copy(alpha = 0.55f * a), p.accent.copy(alpha = 0.25f * a), Color.Transparent),
            startY = baseY - ht, endY = baseY,
        ),
    )
    drawPath(path, p.lavender.copy(alpha = 0.45f * a), style = Stroke(1.2f * density))
    drawLine(p.pearl.copy(alpha = 0.35f * a), Offset(cx + tilt, baseY - ht), Offset(cx + tilt * 0.2f, baseY), 1f * density)
}
