package com.purplenexus.launcher.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.core.tween
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.ui.platform.LocalContext
import com.purplenexus.launcher.data.LyricsRepository
import com.purplenexus.launcher.data.LyricsUi
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.purplenexus.launcher.data.AppInfo
import com.purplenexus.launcher.data.AppRepository
import com.purplenexus.launcher.data.MusicBridge
import com.purplenexus.launcher.data.Prefs
import com.purplenexus.launcher.effects.AmbientBackground
import com.purplenexus.launcher.effects.FxTouch
import com.purplenexus.launcher.effects.ParticleField
import com.purplenexus.launcher.theme.LocalSettings
import com.purplenexus.launcher.theme.Nexus
import com.purplenexus.launcher.theme.NexusSettings
import com.purplenexus.launcher.theme.palette
import kotlinx.coroutines.launch
import kotlin.math.absoluteValue

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun HomeScreen(
    repo: AppRepository,
    prefs: Prefs,
    persisted: NexusSettings?,
    homeTick: Int,
    resumed: Boolean,
) {
    if (persisted == null) {
        Box(Modifier.fillMaxSize().background(Nexus.DeepPurple))
        return
    }

    // Mientras el panel de ajustes está abierto se previsualiza el borrador; se guarda al soltar/cerrar.
    var draft by remember { mutableStateOf<NexusSettings?>(null) }
    val s = draft ?: persisted
    val p = s.palette

    val apps by repo.apps.collectAsState()
    val dockPkgs by prefs.dock.collectAsState(initial = emptyList())
    val folderPkgs by prefs.folder.collectAsState(initial = emptyList())
    val recents by prefs.recents.collectAsState(initial = emptyList())
    val music by MusicBridge.state.collectAsState()

    // Letras: se buscan solo cuando cambia la canción (clave de pista), no en cada tick de reproducción.
    val ctx = LocalContext.current
    val lyricsVersion by LyricsRepository.version.collectAsState()
    val trackKey = music?.trackKey
    val lyricsUi by produceState<LyricsUi>(LyricsUi.None, trackKey, s.lyrics, s.lyricsOnline, lyricsVersion) {
        val m = music
        if (!s.lyrics || m == null) { value = LyricsUi.None; return@produceState }
        value = LyricsUi.Loading
        value = LyricsRepository.load(ctx, m, s.lyricsOnline)
    }

    var drawerOpen by remember { mutableStateOf(false) }
    var focusSearch by remember { mutableStateOf(false) }
    var folderOpen by remember { mutableStateOf(false) }
    var settingsOpen by remember { mutableStateOf(false) }
    var welcome by remember { mutableStateOf(!WelcomeState.shown && persisted.effects) }
    val scope = rememberCoroutineScope()
    val pager = rememberPagerState(pageCount = { 2 })
    val touch = remember { FxTouch() }

    LaunchedEffect(Unit) { WelcomeState.shown = true }
    LaunchedEffect(homeTick) {
        drawerOpen = false; focusSearch = false; folderOpen = false
        if (pager.currentPage != 0) pager.animateScrollToPage(0)
    }

    val dockApps = remember(dockPkgs, apps) { dockPkgs.mapNotNull { k -> apps.firstOrNull { it.pkg == k } } }
    val folderApps = remember(folderPkgs, apps) { folderPkgs.mapNotNull { k -> apps.firstOrNull { it.pkg == k } } }

    val launch: (AppInfo) -> Unit = { app ->
        repo.launch(app, animate = s.effects)
        scope.launch { prefs.pushRecent(app.pkg) }
        drawerOpen = false; focusSearch = false; folderOpen = false
    }
    val closeSettings: () -> Unit = {
        draft?.let { d -> scope.launch { prefs.save(d) } }
        settingsOpen = false
        // el borrador se conserva hasta que DataStore emite el valor guardado
        scope.launch { kotlinx.coroutines.delay(400); draft = null }
    }
    val parallax: () -> Float = { (pager.currentPage + pager.currentPageOffsetFraction) * 2f - 1f }

    BackHandler(drawerOpen || folderOpen || settingsOpen || pager.currentPage != 0) {
        when {
            settingsOpen -> closeSettings()
            folderOpen -> folderOpen = false
            drawerOpen -> { drawerOpen = false; focusSearch = false }
            else -> scope.launch { pager.animateScrollToPage(0) }
        }
    }

    val fxTouch = s.touchFx && s.effects
    CompositionLocalProvider(LocalSettings provides s) {
        Box(
            Modifier
                .fillMaxSize()
                .pointerInput(fxTouch) {
                    awaitPointerEventScope {
                        while (true) {
                            val e = awaitPointerEvent(PointerEventPass.Initial)
                            val c = e.changes.firstOrNull() ?: continue
                            touch.x = c.position.x
                            touch.y = c.position.y
                            if (c.pressed && !touch.down && fxTouch) touch.pendingBurst = true
                            touch.down = c.pressed
                        }
                    }
                }
                .pointerInput(drawerOpen, settingsOpen, folderOpen) {
                    if (!drawerOpen && !settingsOpen && !folderOpen) {
                        var total = 0f
                        detectVerticalDragGestures(
                            onDragStart = { total = 0f },
                            onDragEnd = { if (total < -120f) drawerOpen = true },
                            onVerticalDrag = { _, d -> total += d },
                        )
                    }
                },
        ) {
            AmbientBackground(s, parallax)
            if (s.effects) ParticleField(s, active = resumed, parallax = parallax, touch = touch)

            // Letras sin tarjeta, entre el fondo/partículas y los widgets. Solo en la portada de inicio.
            if (s.lyrics && !drawerOpen && !settingsOpen) {
                val pageFade = 1f - (pager.currentPage + pager.currentPageOffsetFraction).absoluteValue.coerceIn(0f, 1f)
                if (pageFade > 0.01f) {
                    Box(Modifier.fillMaxSize().graphicsLayer { alpha = pageFade }) {
                        LyricsOverlay(lyricsUi, music, active = resumed)
                    }
                }
            }

            HorizontalPager(state = pager, modifier = Modifier.fillMaxSize()) { page ->
                Box(
                    Modifier.fillMaxSize().graphicsLayer {
                        val o = ((pager.currentPage - page) + pager.currentPageOffsetFraction).absoluteValue.coerceIn(0f, 1f)
                        if (s.effects) {
                            alpha = 1f - o * 0.6f
                            scaleX = 1f - o * 0.08f
                            scaleY = 1f - o * 0.08f
                        }
                    },
                ) {
                    if (page == 0) {
                        HomePage(
                            dockApps = dockApps,
                            folderApps = folderApps,
                            onLaunch = launch,
                            onUnpin = { app -> scope.launch { prefs.toggleDock(app.pkg) } },
                            onOpenDrawer = { focusSearch = true; drawerOpen = true },
                            onOpenFolder = { folderOpen = true },
                            onOpenSettings = { draft = persisted; settingsOpen = true },
                        )
                    } else {
                        PanelPage(music, resumed)
                    }
                }
            }

            Box(Modifier.align(Alignment.TopCenter).systemBarsPadding().padding(top = 6.dp)) {
                PageDots(2) { pager.currentPage + pager.currentPageOffsetFraction }
            }

            FolderOverlay(
                visible = folderOpen,
                apps = folderApps,
                onLaunch = launch,
                onRemove = { app -> scope.launch { prefs.toggleFolder(app.pkg) } },
                onClose = { folderOpen = false },
            )

            AnimatedVisibility(
                visible = drawerOpen,
                enter = slideInVertically(tween(380)) { it / 3 } + fadeIn(tween(300)) + scaleIn(tween(380), initialScale = 0.96f),
                exit = slideOutVertically(tween(260)) { it / 3 } + fadeOut(tween(220)),
            ) {
                AppDrawer(
                    apps = apps, dock = dockPkgs, folder = folderPkgs, recents = recents,
                    focusSearch = focusSearch,
                    onLaunch = launch,
                    onToggleDock = { app -> scope.launch { prefs.toggleDock(app.pkg) } },
                    onToggleFolder = { app -> scope.launch { prefs.toggleFolder(app.pkg) } },
                )
            }

            AnimatedVisibility(
                visible = settingsOpen,
                enter = slideInVertically(tween(360)) { it } + fadeIn(),
                exit = slideOutVertically(tween(260)) { it } + fadeOut(),
            ) {
                Column(Modifier.fillMaxSize().tap(closeSettings)) {
                    Spacer(Modifier.weight(0.2f))
                    SettingsPanel(
                        s = s,
                        onChange = { new, persist ->
                            draft = new
                            if (persist) scope.launch { prefs.save(new) }
                        },
                        onReset = {
                            val d = NexusSettings()
                            draft = d
                            scope.launch { prefs.save(d) }
                        },
                        onClose = closeSettings,
                        modifier = Modifier.weight(0.8f).fillMaxWidth(),
                    )
                }
            }

            if (welcome) WelcomeOverlay { welcome = false }
        }
    }
}

@Composable
private fun HomePage(
    dockApps: List<AppInfo>,
    folderApps: List<AppInfo>,
    onLaunch: (AppInfo) -> Unit,
    onUnpin: (AppInfo) -> Unit,
    onOpenDrawer: () -> Unit,
    onOpenFolder: () -> Unit,
    onOpenSettings: () -> Unit,
) {
    val p = LocalSettings.current.palette
    Column(
        Modifier.fillMaxSize().systemBarsPadding().padding(horizontal = 24.dp, vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Row(Modifier.fillMaxWidth().padding(top = 12.dp), horizontalArrangement = Arrangement.End) {
            val tapSound = rememberTapSound()
            Box(
                Modifier.size(44.dp).glass(CircleShape).tap { tapSound(); onOpenSettings() },
                contentAlignment = Alignment.Center,
            ) { GlyphIcon(Glyph.STAR, p.pearl, 20.dp) }
        }
        GlowClock()
        Spacer(Modifier.weight(1f))
        Row(Modifier.fillMaxWidth()) { FolderTile(folderApps, onOpenFolder) }
        Spacer(Modifier.height(14.dp))
        val tapSound = rememberTapSound()
        Row(
            Modifier
                .fillMaxWidth()
                .height(52.dp)
                .glass(Nexus.Pill, sweep = true)
                .tap { tapSound(); onOpenDrawer() }
                .padding(horizontal = 20.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            GlyphIcon(Glyph.SEARCH, p.lavender, 18.dp)
            Spacer(Modifier.size(10.dp))
            Text("Buscar aplicaciones…", color = p.lavender.copy(alpha = 0.85f), fontSize = 15.sp)
        }
        Spacer(Modifier.height(14.dp))
        Row(
            Modifier.fillMaxWidth().height(90.dp).glass(Nexus.Card, ornate = true, sweep = true),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            if (dockApps.isEmpty()) {
                Text("Mantén pulsada una app del cajón para fijarla aquí", color = p.lavender, fontSize = 12.sp)
            } else {
                dockApps.forEach { app ->
                    AppIcon(app, showLabel = false, onClick = { onLaunch(app) }, onLongClick = { onUnpin(app) })
                }
            }
        }
    }
}

@Composable
private fun PanelPage(music: com.purplenexus.launcher.data.MusicState?, active: Boolean) {
    val p = LocalSettings.current.palette
    Column(
        Modifier.fillMaxSize().systemBarsPadding().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Spacer(Modifier.height(14.dp))
        Text("Panel", color = Nexus.White, fontSize = 28.sp, fontWeight = FontWeight.Light)
        OrnamentDivider(width = 120.dp)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            BatteryWidget(Modifier.weight(0.8f))
            CalendarWidget(Modifier.weight(1.3f))
        }
        DeviceWidget(Modifier.fillMaxWidth())
        MusicPanel(music, Modifier.fillMaxWidth(), active = active)
        Spacer(Modifier.height(24.dp))
    }
}
