package com.purplenexus.launcher.data

import android.content.Context
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.security.MessageDigest
import kotlin.math.abs

data class LyricLine(val timeMs: Long, val text: String)

sealed interface LyricsUi {
    data object None : LyricsUi
    data object Loading : LyricsUi
    data class Synced(val lines: List<LyricLine>, val source: String) : LyricsUi
}

/** Analizador de formato LRC. Solo devuelve líneas con marca de tiempo real; nunca genera tiempos. */
object LrcParser {
    private val stamp = Regex("""\[(\d{1,3}):(\d{2})(?:[.:](\d{1,3}))?]""")
    private val offsetTag = Regex("""^\[offset:\s*([+-]?\d+)]""", RegexOption.IGNORE_CASE)

    fun parse(raw: String): List<LyricLine> {
        var offset = 0L
        val out = ArrayList<LyricLine>()
        for (rawLine in raw.lineSequence()) {
            val line = rawLine.trim().removePrefix("\uFEFF")
            if (line.isEmpty()) continue
            offsetTag.find(line)?.let { offset = it.groupValues[1].toLongOrNull() ?: 0L; continue }
            val stamps = stamp.findAll(line).toList()
            if (stamps.isEmpty()) continue // etiquetas [ar:], [ti:]… o texto sin tiempo: se ignoran
            val text = line.substring(stamps.last().range.last + 1).trim()
            for (m in stamps) {
                val min = m.groupValues[1].toLong()
                val sec = m.groupValues[2].toLong()
                val frac = m.groupValues[3]
                val ms = when (frac.length) { 0 -> 0L; 1 -> frac.toLong() * 100; 2 -> frac.toLong() * 10; else -> frac.take(3).toLong() }
                out += LyricLine((min * 60_000 + sec * 1000 + ms - offset).coerceAtLeast(0), text)
            }
        }
        return out.sortedBy { it.timeMs }
    }

    /** Índice de la línea activa en [posMs] (-1 antes de la primera). Búsqueda binaria. */
    fun indexAt(lines: List<LyricLine>, posMs: Long): Int {
        var lo = 0; var hi = lines.size - 1; var ans = -1
        while (lo <= hi) {
            val mid = (lo + hi) ushr 1
            if (lines[mid].timeMs <= posMs) { ans = mid; lo = mid + 1 } else hi = mid - 1
        }
        return ans
    }
}

/**
 * Obtención de letras sincronizadas:
 *  1. Archivo .lrc que el propio usuario importó para esa canción (siempre tiene prioridad).
 *  2. Caché local de una búsqueda anterior.
 *  3. LRCLIB (lrclib.net), servicio comunitario y abierto de letras sincronizadas, solo si el usuario lo permite.
 * No se inventan letras ni tiempos: si ninguna fuente tiene la canción, no se muestra nada.
 * Las letras se guardan únicamente en la caché privada de la app para uso personal y no se redistribuyen.
 */
object LyricsRepository {
    /** Se incrementa al importar un .lrc para que la UI vuelva a cargar. */
    val version = MutableStateFlow(0)

    private const val UA = "PurpleNexus/0.2 (Android launcher; personal use)"
    private const val NEG_TTL_MS = 24L * 3600 * 1000

    private fun dir(ctx: Context) = File(ctx.cacheDir, "lyrics").apply { mkdirs() }
    /** Los .lrc importados por el usuario van en almacenamiento persistente (la caché puede ser purgada por el sistema). */
    private fun userDir(ctx: Context) = File(ctx.filesDir, "lyrics_user").apply { mkdirs() }

    private fun hash(s: MusicState): String {
        val d = MessageDigest.getInstance("SHA-1").digest("${s.title}|${s.artist}|${s.durationMs / 2000}".lowercase().toByteArray())
        return d.joinToString("") { "%02x".format(it) }.take(24)
    }

    suspend fun load(ctx: Context, s: MusicState, allowOnline: Boolean): LyricsUi = withContext(Dispatchers.IO) {
        val base = hash(s)
        val user = File(userDir(ctx), "$base.lrc")
        val cache = File(dir(ctx), "$base.lrc")
        val none = File(dir(ctx), "$base.none")

        runCatching { if (user.exists()) LrcParser.parse(user.readText()).takeIf { it.isNotEmpty() } else null }
            .getOrNull()?.let { return@withContext LyricsUi.Synced(it, "Archivo importado") }
        runCatching { if (cache.exists()) LrcParser.parse(cache.readText()).takeIf { it.isNotEmpty() } else null }
            .getOrNull()?.let { return@withContext LyricsUi.Synced(it, "LRCLIB") }
        if (!allowOnline) return@withContext LyricsUi.None
        if (none.exists() && System.currentTimeMillis() - none.lastModified() < NEG_TTL_MS) return@withContext LyricsUi.None

        val text = runCatching { fetchLrclib(s) }.getOrNull()
        val lines = text?.let { LrcParser.parse(it) }.orEmpty()
        if (lines.isNotEmpty()) {
            runCatching { cache.writeText(text!!) }
            LyricsUi.Synced(lines, "LRCLIB")
        } else {
            // Solo se marca "sin letra" si el servidor respondió; los fallos de red no se cachean.
            if (text != null || lastResponded) runCatching { none.writeText("") }
            LyricsUi.None
        }
    }

    @Volatile private var lastResponded = false

    private fun enc(v: String) = URLEncoder.encode(v, "UTF-8")

    private fun get(url: String): String? {
        val c = (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 6000; readTimeout = 8000
            setRequestProperty("User-Agent", UA)
            setRequestProperty("Accept", "application/json")
        }
        return try {
            when (c.responseCode) {
                200 -> { lastResponded = true; c.inputStream.bufferedReader().use { it.readText() } }
                404 -> { lastResponded = true; null }
                else -> { lastResponded = false; null }
            }
        } finally { c.disconnect() }
    }

    private fun fetchLrclib(s: MusicState): String? {
        lastResponded = false
        val secs = (s.durationMs / 1000).toInt()
        // 1) coincidencia exacta por título + artista (+ álbum y duración si se conocen)
        val exact = buildString {
            append("https://lrclib.net/api/get?track_name=${enc(s.title)}&artist_name=${enc(s.artist)}")
            if (s.album.isNotBlank()) append("&album_name=${enc(s.album)}")
            if (secs > 0) append("&duration=$secs")
        }
        get(exact)?.let { body ->
            val o = JSONObject(body)
            val synced = o.optString("syncedLyrics")
            if (synced.isNotBlank() && !o.isNull("syncedLyrics")) return synced
        }
        // 2) búsqueda más permisiva; se acepta solo si la duración coincide (±3 s) para evitar versiones distintas
        val body = get("https://lrclib.net/api/search?track_name=${enc(s.title)}&artist_name=${enc(s.artist)}") ?: return null
        val arr = JSONArray(body)
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val synced = o.optString("syncedLyrics")
            if (synced.isBlank() || o.isNull("syncedLyrics")) continue
            val d = o.optDouble("duration", -1.0)
            if (secs > 0 && d > 0 && abs(d - secs) > 3.0) continue
            return synced
        }
        return null
    }

    /** Importa un .lrc elegido por el usuario para la canción actual. Devuelve true si tenía líneas sincronizadas. */
    suspend fun importFor(ctx: Context, s: MusicState, uri: Uri): Boolean = withContext(Dispatchers.IO) {
        val text = runCatching {
            ctx.contentResolver.openInputStream(uri)?.use { it.readBytes().takeIf { b -> b.size <= 512 * 1024 }?.toString(Charsets.UTF_8) }
        }.getOrNull() ?: return@withContext false
        if (LrcParser.parse(text).isEmpty()) return@withContext false
        File(userDir(ctx), "${hash(s)}.lrc").writeText(text)
        File(dir(ctx), "${hash(s)}.none").delete()
        version.value++
        true
    }

    fun clearCache(ctx: Context) { dir(ctx).listFiles()?.forEach { it.delete() }; version.value++ }
}
