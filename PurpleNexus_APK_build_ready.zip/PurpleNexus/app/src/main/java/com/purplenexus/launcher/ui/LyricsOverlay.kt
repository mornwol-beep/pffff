package com.purplenexus.launcher.ui

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.snap
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.purplenexus.launcher.data.LrcParser
import com.purplenexus.launcher.data.LyricsUi
import com.purplenexus.launcher.data.MusicState
import com.purplenexus.launcher.theme.GraphicsProfile
import com.purplenexus.launcher.theme.LocalSettings
import com.purplenexus.launcher.theme.Nexus
import kotlinx.coroutines.awaitCancellation
import kotlinx.coroutines.delay
import kotlin.math.abs

/** Posición de reproducción extrapolada. No consume nada si la pantalla no está activa. */
@Composable
fun rememberLivePosition(music: MusicState?, active: Boolean): State<Long> =
    produceState(music?.positionNow() ?: 0L, music, active) {
        value = music?.positionNow() ?: 0L
        if (!active || music == null) awaitCancellation()
        while (true) {
            value = music.positionNow()
            delay(if (music.playing) 120L else 600L)
        }
    }

/**
 * Letras sincronizadas SIN tarjeta ni fondo: texto blanco con brillo violeta en la línea actual.
 * Se dibuja dentro de la propia ventana del launcher (sobre el fondo de pantalla), por lo que desaparece
 * al abrir otra app y nunca se superpone a ellas: no usa SYSTEM_ALERT_WINDOW ni ninguna ventana flotante.
 */
@Composable
fun LyricsOverlay(
    lyrics: LyricsUi,
    music: MusicState?,
    active: Boolean,
    modifier: Modifier = Modifier,
) {
    val synced = lyrics as? LyricsUi.Synced
    if (synced == null || music == null || synced.lines.isEmpty()) return
    val s = LocalSettings.current
    val smooth = s.effects && s.profile != GraphicsProfile.LOW
    val pos = rememberLivePosition(music, active)
    val idxState = remember(synced) { derivedStateOf { LrcParser.indexAt(synced.lines, pos.value) } }
    val cur = idxState.value
    val sizeSp = 14f + 18f * s.lyricsSize

    BoxWithConstraints(modifier.fillMaxSize()) {
        val h = maxHeight * 0.34f
        val top = (maxHeight - h) * s.lyricsY
        val listState = rememberLazyListState()

        LaunchedEffect(synced, cur) {
            val target = cur.coerceAtLeast(0)
            if (smooth) listState.animateScrollToItem(target) else listState.scrollToItem(target)
        }

        LazyColumn(
            state = listState,
            userScrollEnabled = false,
            contentPadding = PaddingValues(top = h * 0.4f, bottom = h * 0.6f),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier
                .offset(y = top)
                .height(h)
                .fillMaxWidth()
                .padding(horizontal = 28.dp)
                .graphicsLayer { compositingStrategy = CompositingStrategy.Offscreen }
                .drawWithContent {
                    drawContent()
                    drawRect(
                        Brush.verticalGradient(
                            0f to Color.Transparent, 0.2f to Color.Black, 0.8f to Color.Black, 1f to Color.Transparent,
                        ),
                        blendMode = BlendMode.DstIn,
                    )
                },
        ) {
            itemsIndexed(synced.lines) { i, line ->
                LyricRow(line.text, abs(i - cur), isCurrent = i == cur, sizeSp = sizeSp, smooth = smooth, glow = s.glow)
            }
        }
    }
}

@Composable
private fun LyricRow(text: String, dist: Int, isCurrent: Boolean, sizeSp: Float, smooth: Boolean, glow: Float) {
    val targetAlpha = when (dist) { 0 -> 1f; 1 -> 0.55f; 2 -> 0.35f; else -> 0.2f }
    val a by animateFloatAsState(targetAlpha, if (smooth) tween(350) else snap(), label = "lyricAlpha")
    val sc by animateFloatAsState(if (isCurrent) 1.08f else 1f, if (smooth) tween(350) else snap(), label = "lyricScale")
    val shadow = if (isCurrent) {
        Shadow(Nexus.Bright.copy(alpha = (0.55f + 0.45f * glow).coerceIn(0f, 1f)), Offset.Zero, 10f + 26f * glow)
    } else {
        Shadow(Color.Black.copy(alpha = 0.55f), Offset.Zero, 6f)
    }
    Text(
        text = text.ifBlank { "♪" },
        color = Color.White,
        fontSize = sizeSp.sp,
        lineHeight = (sizeSp * 1.25f).sp,
        fontWeight = if (isCurrent) FontWeight.Bold else FontWeight.Medium,
        textAlign = TextAlign.Center,
        style = TextStyle(shadow = shadow),
        modifier = Modifier
            .fillMaxWidth()
            .graphicsLayer { alpha = a; scaleX = sc; scaleY = sc },
    )
}
