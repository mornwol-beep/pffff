package com.purplenexus.launcher.data

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.purplenexus.launcher.theme.GraphicsProfile
import com.purplenexus.launcher.theme.NexusFont
import com.purplenexus.launcher.theme.NexusSettings
import com.purplenexus.launcher.theme.StylePreset
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.store by preferencesDataStore("nexus_prefs")

class Prefs(private val ctx: Context) {
    private val kDock = stringPreferencesKey("dock")
    private val kFolder = stringPreferencesKey("folder")
    private val kRecents = stringPreferencesKey("recents")
    private val kStyle = stringPreferencesKey("style")
    private val kProfile = stringPreferencesKey("profile")
    private val kFont = stringPreferencesKey("font")
    private val kEffects = booleanPreferencesKey("effects")
    private val kTouch = booleanPreferencesKey("touch_fx")
    private val kGlassIcons = booleanPreferencesKey("glass_icons")
    private val kDeco = booleanPreferencesKey("decorations")
    private val kSounds = booleanPreferencesKey("sounds")
    private val kParticles = floatPreferencesKey("particles")
    private val kGlass = floatPreferencesKey("glass")
    private val kGlow = floatPreferencesKey("glow")
    private val kLyrics = booleanPreferencesKey("lyrics")
    private val kLyricsOnline = booleanPreferencesKey("lyrics_online")
    private val kLyricsSize = floatPreferencesKey("lyrics_size")
    private val kLyricsY = floatPreferencesKey("lyrics_y")

    private fun parse(raw: String?) = raw?.split("|")?.filter { it.isNotBlank() } ?: emptyList()

    val dock: Flow<List<String>> = ctx.store.data.map { parse(it[kDock]) }
    val folder: Flow<List<String>> = ctx.store.data.map { parse(it[kFolder]) }
    val recents: Flow<List<String>> = ctx.store.data.map { parse(it[kRecents]) }

    val settings: Flow<NexusSettings> = ctx.store.data.map { p ->
        val d = NexusSettings()
        NexusSettings(
            style = p[kStyle]?.let { n -> StylePreset.entries.firstOrNull { it.name == n } } ?: d.style,
            profile = p[kProfile]?.let { n -> GraphicsProfile.entries.firstOrNull { it.name == n } } ?: d.profile,
            font = p[kFont]?.let { n -> NexusFont.entries.firstOrNull { it.name == n } } ?: d.font,
            effects = p[kEffects] ?: d.effects,
            touchFx = p[kTouch] ?: d.touchFx,
            glassIcons = p[kGlassIcons] ?: d.glassIcons,
            decorations = p[kDeco] ?: d.decorations,
            sounds = p[kSounds] ?: d.sounds,
            particles = p[kParticles] ?: d.particles,
            glass = p[kGlass] ?: d.glass,
            glow = p[kGlow] ?: d.glow,
            lyrics = p[kLyrics] ?: d.lyrics,
            lyricsOnline = p[kLyricsOnline] ?: d.lyricsOnline,
            lyricsSize = p[kLyricsSize] ?: d.lyricsSize,
            lyricsY = p[kLyricsY] ?: d.lyricsY,
        )
    }

    suspend fun save(s: NexusSettings) {
        ctx.store.edit { p ->
            p[kStyle] = s.style.name
            p[kProfile] = s.profile.name
            p[kFont] = s.font.name
            p[kEffects] = s.effects
            p[kTouch] = s.touchFx
            p[kGlassIcons] = s.glassIcons
            p[kDeco] = s.decorations
            p[kSounds] = s.sounds
            p[kParticles] = s.particles
            p[kGlass] = s.glass
            p[kGlow] = s.glow
            p[kLyrics] = s.lyrics
            p[kLyricsOnline] = s.lyricsOnline
            p[kLyricsSize] = s.lyricsSize
            p[kLyricsY] = s.lyricsY
        }
    }

    /** Fija o quita una app del dock (máximo 4). */
    suspend fun toggleDock(pkg: String) = toggle(kDock, pkg, MAX_DOCK)

    /** Añade o quita una app de la carpeta. */
    suspend fun toggleFolder(pkg: String) = toggle(kFolder, pkg, MAX_FOLDER)

    suspend fun pushRecent(pkg: String) {
        ctx.store.edit { p ->
            val cur = parse(p[kRecents]).toMutableList()
            cur.remove(pkg)
            cur.add(0, pkg)
            p[kRecents] = cur.take(MAX_RECENTS).joinToString("|")
        }
    }

    private suspend fun toggle(key: androidx.datastore.preferences.core.Preferences.Key<String>, pkg: String, max: Int) {
        ctx.store.edit { p ->
            val cur = parse(p[key]).toMutableList()
            if (!cur.remove(pkg) && cur.size < max) cur.add(pkg)
            p[key] = cur.joinToString("|")
        }
    }

    companion object {
        const val MAX_DOCK = 4
        const val MAX_FOLDER = 12
        const val MAX_RECENTS = 12
    }
}
