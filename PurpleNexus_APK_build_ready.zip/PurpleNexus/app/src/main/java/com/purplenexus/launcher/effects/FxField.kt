package com.purplenexus.launcher.effects

import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.IntSize
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.withFrameNanos
import com.purplenexus.launcher.theme.Kind
import com.purplenexus.launcher.theme.NexusSettings
import com.purplenexus.launcher.theme.Palette
import com.purplenexus.launcher.theme.palette
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.random.Random

class FxTouch {
    var x = 0f
    var y = 0f
    var down = false
    var pendingBurst = false
}

/** Motor de partículas con arrays planos (sin asignaciones por fotograma). */
class FxEngine(private val capacity: Int = 160) {
    private val x = FloatArray(capacity)
    private val y = FloatArray(capacity)
    private val z = FloatArray(capacity)
    private val vx = FloatArray(capacity)
    private val vy = FloatArray(capacity)
    private val bvx = FloatArray(capacity)
    private val bvy = FloatArray(capacity)
    private val ph = FloatArray(capacity)
    private val sz = FloatArray(capacity)
    private val kind = IntArray(capacity)
    var count = 0
        private set
    var time = 0f
        private set
    private var w = 1f
    private var h = 1f
    private var d = 1f
    private val rnd = Random(System.nanoTime())

    private val rx = FloatArray(MAX_R)
    private val ry = FloatArray(MAX_R)
    private val rAge = FloatArray(MAX_R) { -1f }
    private var rNext = 0

    fun setup(n: Int, kinds: IntArray, width: Float, height: Float, density: Float) {
        w = width; h = height; d = density
        count = n.coerceIn(0, capacity)
        for (i in 0 until count) {
            kind[i] = kinds[i % kinds.size]
            spawn(i, true)
        }
    }

    private fun spawn(i: Int, initial: Boolean) {
        val zi = 0.35f + rnd.nextFloat() * 0.65f
        z[i] = zi
        ph[i] = rnd.nextFloat() * 6.283f
        x[i] = rnd.nextFloat() * w
        when (kind[i]) {
            Kind.STAR -> {
                y[i] = rnd.nextFloat() * h
                bvx[i] = 0f; bvy[i] = 0f
                sz[i] = (0.9f + rnd.nextFloat() * 1.6f) * d * zi
            }
            Kind.DUST -> {
                y[i] = if (initial) rnd.nextFloat() * h else h + 10f
                bvx[i] = 0f; bvy[i] = -(8f + rnd.nextFloat() * 18f) * zi * d
                sz[i] = (1.2f + rnd.nextFloat() * 1.8f) * d * zi
            }
            Kind.RAIN -> {
                y[i] = if (initial) rnd.nextFloat() * h else -40f
                bvx[i] = -110f * zi * d; bvy[i] = (650f + rnd.nextFloat() * 450f) * zi * d
                sz[i] = 1.1f * d * zi
            }
            else -> {
                y[i] = if (initial) rnd.nextFloat() * h else h + 20f
                bvx[i] = 0f; bvy[i] = -(18f + rnd.nextFloat() * 34f) * zi * d
                sz[i] = (4f + rnd.nextFloat() * 8f) * d * zi
            }
        }
        vx[i] = bvx[i]; vy[i] = bvy[i]
    }

    fun burst(px: Float, py: Float) {
        rx[rNext] = px; ry[rNext] = py; rAge[rNext] = 0f
        rNext = (rNext + 1) % MAX_R
        val radius = 230f * d
        for (i in 0 until count) {
            val dx = x[i] - px
            val dy = y[i] - py
            val d2 = dx * dx + dy * dy
            if (d2 < radius * radius && d2 > 1f) {
                val dist = sqrt(d2)
                val f = (1f - dist / radius) * 340f * z[i] * d
                vx[i] += dx / dist * f
                vy[i] += dy / dist * f
            }
        }
    }

    fun step(dt: Float, tx: Float, ty: Float, touching: Boolean) {
        time += dt
        val radius = 150f * d
        val k = (1.8f * dt).coerceAtMost(1f)
        for (i in 0 until count) {
            if (touching) {
                val dx = x[i] - tx
                val dy = y[i] - ty
                val d2 = dx * dx + dy * dy
                if (d2 < radius * radius && d2 > 1f) {
                    val dist = sqrt(d2)
                    val f = (1f - dist / radius) * 900f * dt * z[i] * d
                    vx[i] += dx / dist * f
                    vy[i] += dy / dist * f * 0.6f
                }
            }
            vx[i] += (bvx[i] - vx[i]) * k
            vy[i] += (bvy[i] - vy[i]) * k
            x[i] += vx[i] * dt
            y[i] += vy[i] * dt
            if (kind[i] == Kind.BUBBLE) x[i] += sin(time * 1.2f + ph[i]) * 10f * d * dt
            if (x[i] < -30f) x[i] = w + 30f else if (x[i] > w + 30f) x[i] = -30f
            when (kind[i]) {
                Kind.RAIN -> if (y[i] > h + 60f) spawn(i, false)
                Kind.DUST, Kind.BUBBLE -> if (y[i] < -30f) spawn(i, false)
                else -> if (y[i] < -30f) y[i] = h + 30f else if (y[i] > h + 30f) y[i] = -30f
            }
        }
        for (j in 0 until MAX_R) {
            if (rAge[j] >= 0f) {
                rAge[j] += dt
                if (rAge[j] > RIPPLE_LIFE) rAge[j] = -1f
            }
        }
    }

    fun DrawScope.render(p: Palette, parallax: Float, intensity: Float) {
        val shift = parallax * 46f * d
        for (i in 0 until count) {
            val zi = z[i]
            val px = x[i] + shift * zi
            val py = y[i]
            val a = ((0.25f + 0.75f * zi) * intensity).coerceIn(0f, 1f)
            val c = Offset(px, py)
            when (kind[i]) {
                Kind.STAR -> {
                    val tw = 0.55f + 0.45f * sin(time * (1.2f + zi) + ph[i])
                    val aa = a * tw
                    drawCircle(p.pearl.copy(alpha = aa), sz[i], c)
                    if (sz[i] > 1.9f * d) {
                        val l = sz[i] * 3.2f
                        drawLine(p.pearl.copy(alpha = aa * 0.6f), Offset(px - l, py), Offset(px + l, py), 1f)
                        drawLine(p.pearl.copy(alpha = aa * 0.6f), Offset(px, py - l), Offset(px, py + l), 1f)
                    }
                }
                Kind.DUST -> {
                    drawCircle(p.lavender.copy(alpha = a * 0.16f), sz[i] * 3.2f, c)
                    drawCircle(p.pearl.copy(alpha = a * 0.9f), sz[i], c)
                }
                Kind.RAIN -> {
                    drawLine(
                        p.lavender.copy(alpha = a * 0.6f), c,
                        Offset(px - vx[i] * 0.05f, py - vy[i] * 0.05f),
                        strokeWidth = sz[i],
                    )
                }
                else -> {
                    drawCircle(p.cyan.copy(alpha = a * 0.08f), sz[i], c)
                    drawCircle(p.cyan.copy(alpha = a * 0.55f), sz[i], c, style = Stroke(1.2f * d))
                    drawCircle(Color.White.copy(alpha = a * 0.7f), sz[i] * 0.22f, Offset(px - sz[i] * 0.35f, py - sz[i] * 0.35f))
                }
            }
        }
        for (j in 0 until MAX_R) {
            val age = rAge[j]
            if (age >= 0f) {
                val prog = age / RIPPLE_LIFE
                val fade = (1f - prog) * intensity.coerceAtLeast(0.5f)
                val r = (18f + prog * 150f) * d
                val c = Offset(rx[j], ry[j])
                drawCircle(p.cyan.copy(alpha = fade * 0.55f), r, c, style = Stroke(2.2f * d * (1f - prog) + 0.6f))
                drawCircle(p.lavender.copy(alpha = fade * 0.4f), r * 0.62f, c, style = Stroke(1.4f * d))
            }
        }
    }

    companion object {
        private const val MAX_R = 6
        private const val RIPPLE_LIFE = 1.1f
    }
}

@Composable
fun ParticleField(
    s: NexusSettings,
    active: Boolean,
    parallax: () -> Float,
    touch: FxTouch,
    modifier: Modifier = Modifier,
) {
    val p = s.palette
    val density = LocalDensity.current.density
    val engine = remember { FxEngine(160) }
    val frame = remember { mutableLongStateOf(0L) }
    var size by remember { mutableStateOf(IntSize.Zero) }
    val n = (s.profile.particleBase * (0.2f + 1.6f * s.particles)).toInt()

    LaunchedEffect(size, s.style, n) {
        if (size.width > 0 && size.height > 0) {
            engine.setup(n, s.style.kinds, size.width.toFloat(), size.height.toFloat(), density)
            frame.longValue = frame.longValue + 1
        }
    }

    LaunchedEffect(active, s.profile, s.touchFx) {
        if (!active) return@LaunchedEffect
        var last = 0L
        val minGap = s.profile.frameMs * 1_000_000L
        while (true) {
            withFrameNanos { now ->
                if (last == 0L) {
                    last = now
                } else if (now - last >= minGap) {
                    val dt = ((now - last) / 1_000_000_000f).coerceAtMost(0.05f)
                    last = now
                    if (touch.pendingBurst) {
                        touch.pendingBurst = false
                        if (s.touchFx) engine.burst(touch.x, touch.y)
                    }
                    engine.step(dt, touch.x, touch.y, touch.down && s.touchFx)
                    frame.longValue = now
                }
            }
        }
    }

    Canvas(modifier.fillMaxSize().onSizeChanged { size = it }) {
        frame.longValue // lectura: invalida solo el dibujo en cada fotograma
        val par = parallax()
        with(engine) { render(p, par, 0.35f + 0.65f * s.glow) }
    }
}
