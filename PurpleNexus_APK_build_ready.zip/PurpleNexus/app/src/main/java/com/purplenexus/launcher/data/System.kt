package com.purplenexus.launcher.data

import android.app.ActivityManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import kotlinx.coroutines.delay

data class BatteryInfo(val level: Int = -1, val charging: Boolean = false, val tempC: Float = 0f)
data class MemInfo(val usedPct: Int = 0, val totalGb: Float = 0f)

@Composable
fun rememberBattery(): State<BatteryInfo> {
    val ctx = LocalContext.current
    val state = remember { mutableStateOf(BatteryInfo()) }
    DisposableEffect(ctx) {
        fun parse(i: Intent?) {
            if (i == null) return
            val lvl = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
            val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100).coerceAtLeast(1)
            val st = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
            val t = i.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) / 10f
            state.value = BatteryInfo(
                level = if (lvl < 0) -1 else lvl * 100 / scale,
                charging = st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL,
                tempC = t,
            )
        }
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(c: Context?, i: Intent?) { parse(i) }
        }
        val sticky = ContextCompat.registerReceiver(
            ctx, receiver, IntentFilter(Intent.ACTION_BATTERY_CHANGED), ContextCompat.RECEIVER_NOT_EXPORTED,
        )
        parse(sticky)
        onDispose { ctx.unregisterReceiver(receiver) }
    }
    return state
}

@Composable
fun rememberMemory(): State<MemInfo> {
    val ctx = LocalContext.current
    return produceState(MemInfo()) {
        val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        while (true) {
            val mi = ActivityManager.MemoryInfo()
            am.getMemoryInfo(mi)
            if (mi.totalMem > 0) {
                value = MemInfo(
                    usedPct = ((mi.totalMem - mi.availMem) * 100 / mi.totalMem).toInt(),
                    totalGb = mi.totalMem / 1073741824f,
                )
            }
            delay(5000)
        }
    }
}
