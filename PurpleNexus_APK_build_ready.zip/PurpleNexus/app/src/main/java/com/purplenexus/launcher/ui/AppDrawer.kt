package com.purplenexus.launcher.ui

import android.content.pm.ApplicationInfo
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.purplenexus.launcher.data.AppInfo
import com.purplenexus.launcher.data.Prefs
import com.purplenexus.launcher.theme.LocalSettings
import com.purplenexus.launcher.theme.Nexus
import com.purplenexus.launcher.theme.palette
import kotlinx.coroutines.delay

private enum class DrawerTab(val label: String) {
    ALL("Todas"), RECENT("Recientes"), FAV("Favoritas"),
    GAMES("Juegos"), SOCIAL("Social"), MEDIA("Multimedia"), WORK("Productividad"),
}

@Composable
fun AppDrawer(
    apps: List<AppInfo>,
    dock: List<String>,
    folder: List<String>,
    recents: List<String>,
    focusSearch: Boolean,
    onLaunch: (AppInfo) -> Unit,
    onToggleDock: (AppInfo) -> Unit,
    onToggleFolder: (AppInfo) -> Unit,
    modifier: Modifier = Modifier,
) {
    val s = LocalSettings.current
    val p = s.palette
    var query by remember { mutableStateOf("") }
    var tab by remember { mutableStateOf(DrawerTab.ALL) }
    var menuFor by remember { mutableStateOf<String?>(null) }
    val focus = remember { FocusRequester() }
    LaunchedEffect(focusSearch) { if (focusSearch) runCatching { focus.requestFocus() } }

    val list = remember(apps, query, tab, dock, folder, recents) {
        val base = when {
            query.isNotBlank() -> apps
            else -> when (tab) {
                DrawerTab.ALL -> apps
                DrawerTab.RECENT -> recents.mapNotNull { r -> apps.firstOrNull { it.pkg == r } }
                DrawerTab.FAV -> apps.filter { it.pkg in dock || it.pkg in folder }
                DrawerTab.GAMES -> apps.filter { it.category == ApplicationInfo.CATEGORY_GAME }
                DrawerTab.SOCIAL -> apps.filter { it.category == ApplicationInfo.CATEGORY_SOCIAL }
                DrawerTab.MEDIA -> apps.filter {
                    it.category == ApplicationInfo.CATEGORY_AUDIO || it.category == ApplicationInfo.CATEGORY_VIDEO ||
                        it.category == ApplicationInfo.CATEGORY_IMAGE
                }
                DrawerTab.WORK -> apps.filter { it.category == ApplicationInfo.CATEGORY_PRODUCTIVITY }
            }
        }
        if (query.isBlank()) base else base.filter { it.label.contains(query.trim(), ignoreCase = true) }
    }

    val shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp)
    Column(
        modifier
            .fillMaxSize()
            .background(p.bgTop.copy(alpha = 0.82f), shape)
            .glass(shape, ornate = true)
            .systemBarsPadding()
            .padding(horizontal = 16.dp),
    ) {
        TextField(
            value = query,
            onValueChange = { query = it },
            placeholder = { Text("Buscar aplicaciones…", color = p.lavender.copy(alpha = 0.7f)) },
            singleLine = true,
            shape = Nexus.Pill,
            colors = TextFieldDefaults.colors(
                focusedContainerColor = Color.White.copy(alpha = 0.08f),
                unfocusedContainerColor = Color.White.copy(alpha = 0.06f),
                focusedIndicatorColor = Color.Transparent,
                unfocusedIndicatorColor = Color.Transparent,
                focusedTextColor = Nexus.White,
                unfocusedTextColor = Nexus.White,
                cursorColor = p.accent,
            ),
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 16.dp, bottom = 10.dp)
                .border(1.dp, p.lavender.copy(alpha = 0.35f), Nexus.Pill)
                .focusRequester(focus),
        )
        Row(
            Modifier.horizontalScroll(rememberScrollState()).padding(bottom = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            DrawerTab.entries.forEach { t ->
                val sel = t == tab && query.isBlank()
                Box(
                    Modifier
                        .background(if (sel) p.accent.copy(alpha = 0.3f) else Color.Transparent, Nexus.Pill)
                        .border(1.dp, p.lavender.copy(alpha = if (sel) 0.8f else 0.2f), Nexus.Pill)
                        .tap { tab = t; query = "" }
                        .padding(horizontal = 14.dp, vertical = 7.dp),
                ) {
                    Text(t.label, color = if (sel) Nexus.White else p.lavender, fontSize = 13.sp)
                }
            }
        }
        if (list.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
                Text(
                    if (tab == DrawerTab.RECENT && query.isBlank()) "Aún no has abierto apps desde aquí" else "Nada por aquí todavía",
                    color = p.lavender.copy(alpha = 0.8f), fontSize = 14.sp, modifier = Modifier.padding(top = 40.dp),
                )
            }
        } else {
            LazyVerticalGrid(
                columns = GridCells.Fixed(4),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
                modifier = Modifier.fillMaxSize(),
            ) {
                itemsIndexed(list, key = { _, a -> a.pkg + a.activity }) { index, app ->
                    val appear = remember { Animatable(if (s.effects) 0f else 1f) }
                    LaunchedEffect(Unit) {
                        if (s.effects) {
                            delay((index % 20) * 22L)
                            appear.animateTo(1f, tween(300))
                        }
                    }
                    Box(
                        Modifier.graphicsLayer {
                            alpha = appear.value
                            val sc = 0.8f + 0.2f * appear.value
                            scaleX = sc; scaleY = sc
                            translationY = (1f - appear.value) * 24f
                        },
                        contentAlignment = Alignment.Center,
                    ) {
                        AppIcon(app, onClick = { onLaunch(app) }, onLongClick = { menuFor = app.pkg })
                        DropdownMenu(
                            expanded = menuFor == app.pkg,
                            onDismissRequest = { menuFor = null },
                            modifier = Modifier.background(p.bgMid),
                        ) {
                            val inDock = app.pkg in dock
                            val dockFull = !inDock && dock.size >= Prefs.MAX_DOCK
                            DropdownMenuItem(
                                text = {
                                    Text(
                                        when {
                                            inDock -> "Quitar del dock"
                                            dockFull -> "Dock lleno (máx. ${Prefs.MAX_DOCK})"
                                            else -> "Fijar en el dock"
                                        },
                                        color = Nexus.White,
                                    )
                                },
                                enabled = !dockFull,
                                onClick = { onToggleDock(app); menuFor = null },
                            )
                            DropdownMenuItem(
                                text = { Text(if (app.pkg in folder) "Quitar de la carpeta" else "Añadir a la carpeta", color = Nexus.White) },
                                onClick = { onToggleFolder(app); menuFor = null },
                            )
                        }
                    }
                }
            }
        }
    }
}
