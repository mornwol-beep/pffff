package com.purplenexus.launcher.ui

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.EnterTransition
import androidx.compose.animation.ExitTransition
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.core.tween
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.purplenexus.launcher.effects.sparkle
import com.purplenexus.launcher.theme.LocalSettings
import com.purplenexus.launcher.theme.palette
import kotlinx.coroutines.delay
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun GlowClock(modifier: Modifier = Modifier) {
    val s = LocalSettings.current
    val p = s.palette
    val now by produceState(LocalDateTime.now()) {
        while (true) {
            value = LocalDateTime.now()
            delay(60_000L - (System.currentTimeMillis() % 60_000L) + 30L)
        }
    }
    val es = Locale("es", "ES")
    val time = now.format(DateTimeFormatter.ofPattern("HH:mm"))
    val date = now.format(DateTimeFormatter.ofPattern("EEEE, d 'de' MMMM", es)).replaceFirstChar { it.uppercase() }
    val style = TextStyle(
        brush = Brush.verticalGradient(listOf(p.pearl, p.lavender)),
        fontFamily = s.font.family,
        fontWeight = FontWeight.Light,
        fontSize = 88.sp,
        fontFeatureSettings = "tnum",
        shadow = Shadow(p.accent.copy(alpha = 0.9f * s.glow), Offset.Zero, 24f + 40f * s.glow),
    )

    Box(modifier.fillMaxWidth().height(250.dp), contentAlignment = Alignment.Center) {
        if (s.decorations) OrbitRing()
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Row {
                time.forEach { ch ->
                    AnimatedContent(
                        targetState = ch,
                        transitionSpec = {
                            if (s.effects) {
                                (slideInVertically(tween(380)) { -it / 2 } + fadeIn(tween(380))) togetherWith
                                    (slideOutVertically(tween(300)) { it / 2 } + fadeOut(tween(250)))
                            } else {
                                EnterTransition.None togetherWith ExitTransition.None
                            }
                        },
                        label = "digit",
                    ) { c -> Text(c.toString(), style = style) }
                }
            }
            Text(date, color = p.lavender, fontSize = 16.sp, fontFamily = s.font.family, letterSpacing = 1.sp)
            Spacer(Modifier.height(10.dp))
            OrnamentDivider()
        }
    }
}

@Composable
private fun OrbitRing() {
    val s = LocalSettings.current
    val p = s.palette
    val rot = rememberPhase(s.effects, 48000)
    Canvas(Modifier.fillMaxSize()) {
        val c = center
        val rx = size.width * 0.48f
        val ry = size.height * 0.46f
        val deg = rot.value * 360f
        val sw = Stroke(1.2.dp.toPx())
        rotate(deg, pivot = c) {
            drawArc(p.lavender.copy(alpha = 0.45f), 0f, 70f, false, Offset(c.x - rx, c.y - ry), Size(rx * 2, ry * 2), style = sw)
            drawArc(p.cyan.copy(alpha = 0.35f), 180f, 40f, false, Offset(c.x - rx, c.y - ry), Size(rx * 2, ry * 2), style = sw)
            val a = (70f * PI / 180f).toFloat()
            drawCircle(p.pearl, 2.5.dp.toPx(), Offset(c.x + rx * cos(a), c.y + ry * sin(a)))
        }
        rotate(-deg * 0.6f, pivot = c) {
            val r2x = rx * 0.9f
            val r2y = ry * 0.88f
            drawArc(p.accent.copy(alpha = 0.4f), 90f, 55f, false, Offset(c.x - r2x, c.y - r2y), Size(r2x * 2, r2y * 2), style = sw)
        }
        val tw = 0.5f + 0.5f * sin(rot.value * 2f * PI.toFloat() * 3f)
        sparkle(Offset(c.x - rx * 0.92f, c.y - ry * 0.35f), 6.dp.toPx(), p.pearl.copy(alpha = 0.3f + 0.6f * tw))
        sparkle(Offset(c.x + rx * 0.9f, c.y + ry * 0.4f), 5.dp.toPx(), p.cyan.copy(alpha = 0.9f - 0.6f * tw))
        sparkle(Offset(c.x + rx * 0.7f, c.y - ry * 0.8f), 4.dp.toPx(), p.lavender.copy(alpha = 0.3f + 0.5f * tw))
    }
}
