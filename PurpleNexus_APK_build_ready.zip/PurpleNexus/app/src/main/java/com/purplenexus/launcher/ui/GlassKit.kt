package com.purplenexus.launcher.ui

import android.view.SoundEffectConstants
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.purplenexus.launcher.effects.cornerOrnaments
import com.purplenexus.launcher.theme.GraphicsProfile
import com.purplenexus.launcher.theme.LocalSettings
import com.purplenexus.launcher.theme.Nexus
import com.purplenexus.launcher.theme.palette
import kotlin.math.abs

/** Fase 0..1 en bucle; si está desactivada queda fija en 0 (sin coste de animación). */
@Composable
fun rememberPhase(enabled: Boolean, periodMs: Int): State<Float> =
    if (enabled) {
        rememberInfiniteTransition(label = "phase").animateFloat(
            initialValue = 0f,
            targetValue = 1f,
            animationSpec = infiniteRepeatable(tween(periodMs, easing = LinearEasing)),
            label = "p",
        )
    } else {
        remember { mutableStateOf(0f) }
    }

@Composable
fun rememberTapSound(): () -> Unit {
    val view = LocalView.current
    val on = LocalSettings.current.sounds
    return remember(view, on) { { if (on) view.playSoundEffect(SoundEffectConstants.CLICK) } }
}

@Composable
fun Modifier.tap(onClick: () -> Unit): Modifier =
    this.clickable(interactionSource = remember { MutableInteractionSource() }, indication = null, onClick = onClick)

/** Panel de cristal: relleno translúcido, borde luminoso, esquinas ornamentales y brillo opcional. */
@Composable
fun Modifier.glass(shape: Shape = Nexus.Card, ornate: Boolean = false, sweep: Boolean = false): Modifier {
    val s = LocalSettings.current
    val p = s.palette
    val a = s.glass
    val border = Brush.linearGradient(
        listOf(p.lavender.copy(alpha = 0.75f), p.cyan.copy(alpha = 0.25f), p.accent.copy(alpha = 0.55f)),
    )
    val fill = Brush.verticalGradient(
        listOf(Color.White.copy(alpha = 0.05f + 0.11f * a), p.bgMid.copy(alpha = 0.25f + 0.45f * a)),
    )
    var m = this.background(fill, shape).border(1.dp, border, shape)
    if (sweep && s.effects && s.profile != GraphicsProfile.LOW) m = m.sweepShine(shape)
    if (ornate && s.decorations) {
        val c = p.lavender.copy(alpha = 0.6f)
        m = m.drawBehind { cornerOrnaments(c, 6.dp.toPx(), 14.dp.toPx()) }
    }
    return m
}

@Composable
private fun Modifier.sweepShine(shape: Shape): Modifier {
    val t = rememberPhase(true, 5600)
    return this.clip(shape).drawWithContent {
        drawContent()
        val x = size.width * (t.value * 2.4f - 0.7f)
        val a = Offset(x - 60.dp.toPx(), 0f)
        val b = Offset(x + 60.dp.toPx(), size.height * 0.5f)
        drawRect(
            Brush.linearGradient(
                colors = listOf(Color.Transparent, Color.White.copy(alpha = 0.16f), Color.Transparent),
                start = a, end = b,
            ),
        )
    }
}

enum class Glyph { STAR, PLAY, PAUSE, PREV, NEXT, CLOSE, SEARCH }

@Composable
fun GlyphIcon(glyph: Glyph, tint: Color, size: Dp = 22.dp, modifier: Modifier = Modifier) {
    Canvas(modifier.size(size)) {
        val w = this.size.width
        val h = this.size.height
        val sw = 2.dp.toPx()
        when (glyph) {
            Glyph.STAR -> {
                val c = Offset(w / 2, h / 2)
                val i = w * 0.14f
                val path = Path().apply {
                    moveTo(c.x, 0f)
                    lineTo(c.x + i, c.y - i)
                    lineTo(w, c.y)
                    lineTo(c.x + i, c.y + i)
                    lineTo(c.x, h)
                    lineTo(c.x - i, c.y + i)
                    lineTo(0f, c.y)
                    lineTo(c.x - i, c.y - i)
                    close()
                }
                drawPath(path, tint)
            }
            Glyph.PLAY -> {
                val path = Path().apply {
                    moveTo(w * 0.25f, h * 0.15f); lineTo(w * 0.85f, h * 0.5f); lineTo(w * 0.25f, h * 0.85f); close()
                }
                drawPath(path, tint)
            }
            Glyph.PAUSE -> {
                drawRoundRect(tint, Offset(w * 0.2f, h * 0.15f), Size(w * 0.2f, h * 0.7f), CornerRadius(2.dp.toPx()))
                drawRoundRect(tint, Offset(w * 0.6f, h * 0.15f), Size(w * 0.2f, h * 0.7f), CornerRadius(2.dp.toPx()))
            }
            Glyph.PREV -> {
                drawRoundRect(tint, Offset(w * 0.15f, h * 0.2f), Size(w * 0.12f, h * 0.6f), CornerRadius(2.dp.toPx()))
                val path = Path().apply {
                    moveTo(w * 0.88f, h * 0.18f); lineTo(w * 0.35f, h * 0.5f); lineTo(w * 0.88f, h * 0.82f); close()
                }
                drawPath(path, tint)
            }
            Glyph.NEXT -> {
                drawRoundRect(tint, Offset(w * 0.73f, h * 0.2f), Size(w * 0.12f, h * 0.6f), CornerRadius(2.dp.toPx()))
                val path = Path().apply {
                    moveTo(w * 0.12f, h * 0.18f); lineTo(w * 0.65f, h * 0.5f); lineTo(w * 0.12f, h * 0.82f); close()
                }
                drawPath(path, tint)
            }
            Glyph.CLOSE -> {
                drawLine(tint, Offset(w * 0.2f, h * 0.2f), Offset(w * 0.8f, h * 0.8f), sw, StrokeCap.Round)
                drawLine(tint, Offset(w * 0.8f, h * 0.2f), Offset(w * 0.2f, h * 0.8f), sw, StrokeCap.Round)
            }
            Glyph.SEARCH -> {
                drawCircle(tint, w * 0.28f, Offset(w * 0.42f, h * 0.42f), style = Stroke(sw))
                drawLine(tint, Offset(w * 0.64f, h * 0.64f), Offset(w * 0.88f, h * 0.88f), sw, StrokeCap.Round)
            }
        }
    }
}

/** Línea ornamental con rombo central. */
@Composable
fun OrnamentDivider(modifier: Modifier = Modifier, width: Dp = 180.dp) {
    val p = LocalSettings.current.palette
    Canvas(modifier.size(width, 14.dp)) {
        val cy = size.height / 2
        val cx = size.width / 2
        val gap = 10.dp.toPx()
        drawLine(
            Brush.horizontalGradient(listOf(Color.Transparent, p.lavender.copy(alpha = 0.8f)), startX = 0f, endX = cx - gap),
            Offset(0f, cy), Offset(cx - gap, cy), strokeWidth = 1.dp.toPx(),
        )
        drawLine(
            Brush.horizontalGradient(listOf(p.lavender.copy(alpha = 0.8f), Color.Transparent), startX = cx + gap, endX = size.width),
            Offset(cx + gap, cy), Offset(size.width, cy), strokeWidth = 1.dp.toPx(),
        )
        val d = 4.dp.toPx()
        val diamond = Path().apply {
            moveTo(cx, cy - d); lineTo(cx + d, cy); lineTo(cx, cy + d); lineTo(cx - d, cy); close()
        }
        drawPath(diamond, p.cyan)
    }
}

@Composable
fun PageDots(count: Int, position: () -> Float) {
    val p = LocalSettings.current.palette
    val pos = position()
    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
        repeat(count) { i ->
            val near = (1f - abs(pos - i)).coerceIn(0f, 1f)
            Box(
                Modifier
                    .size(width = (6f + 12f * near).dp, height = 6.dp)
                    .background(p.lavender.copy(alpha = 0.3f + 0.7f * near), CircleShape),
            )
        }
    }
}

/** Barra de progreso luminosa. */
@Composable
fun GlowBar(fraction: Float, modifier: Modifier = Modifier) {
    val p = LocalSettings.current.palette
    Canvas(modifier.fillMaxWidth().height(8.dp)) {
        val r = CornerRadius(size.height / 2)
        drawRoundRect(Color.White.copy(alpha = 0.1f), cornerRadius = r)
        val fw = size.width * fraction.coerceIn(0f, 1f)
        if (fw > 0f) {
            drawRoundRect(
                Brush.horizontalGradient(listOf(p.accent, p.cyan), startX = 0f, endX = size.width),
                size = Size(fw, size.height), cornerRadius = r,
            )
            drawCircle(p.cyan.copy(alpha = 0.35f), size.height * 1.1f, Offset(fw, size.height / 2))
            drawCircle(p.pearl, size.height * 0.5f, Offset(fw, size.height / 2))
        }
    }
}
