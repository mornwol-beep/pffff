package com.purplenexus.launcher.ui

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.purplenexus.launcher.data.AppInfo
import com.purplenexus.launcher.theme.LocalSettings
import com.purplenexus.launcher.theme.Nexus
import com.purplenexus.launcher.theme.palette

/**
 * Icono de app. Con "marcos de cristal" activado el icono original va dentro de un marco luminoso;
 * al desactivarlo se muestra el icono original sin ningún marco.
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun AppIcon(
    app: AppInfo,
    showLabel: Boolean = true,
    onClick: () -> Unit,
    onLongClick: () -> Unit,
) {
    val s = LocalSettings.current
    val p = s.palette
    val source = remember { MutableInteractionSource() }
    val pressed by source.collectIsPressedAsState()
    val scale by animateFloatAsState(if (pressed) 0.86f else 1f, spring(dampingRatio = 0.45f, stiffness = 500f), label = "press")
    val glowA by animateFloatAsState(if (pressed) 1f else 0.45f, label = "glow")
    val haptic = LocalHapticFeedback.current
    val tapSound = rememberTapSound()

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .graphicsLayer { scaleX = scale; scaleY = scale }
            .combinedClickable(
                interactionSource = source,
                indication = null,
                onClick = { tapSound(); onClick() },
                onLongClick = { haptic.performHapticFeedback(HapticFeedbackType.LongPress); onLongClick() },
            )
            .padding(6.dp),
    ) {
        if (s.glassIcons) {
            val shape = RoundedCornerShape(18.dp)
            Box(
                Modifier
                    .size(60.dp)
                    .shadow(if (s.effects) 10.dp else 0.dp, shape, ambientColor = p.accent, spotColor = p.accent)
                    .background(Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.16f), p.bgMid.copy(alpha = 0.55f))), shape)
                    .border(
                        1.2.dp,
                        Brush.linearGradient(
                            listOf(p.lavender.copy(alpha = glowA), p.cyan.copy(alpha = glowA * 0.4f), p.accent.copy(alpha = glowA * 0.8f)),
                        ),
                        shape,
                    )
                    .drawBehind {
                        drawLine(
                            Color.White.copy(alpha = 0.35f),
                            Offset(size.width * 0.18f, 3.dp.toPx()), Offset(size.width * 0.82f, 3.dp.toPx()),
                            1.dp.toPx(), StrokeCap.Round,
                        )
                    },
                contentAlignment = Alignment.Center,
            ) {
                Image(bitmap = app.icon, contentDescription = app.label, modifier = Modifier.size(40.dp))
            }
        } else {
            Image(bitmap = app.icon, contentDescription = app.label, modifier = Modifier.size(56.dp))
        }
        if (showLabel) {
            Spacer(Modifier.height(5.dp))
            Text(
                app.label, color = Nexus.White, fontSize = 11.sp, maxLines = 1,
                overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center,
                modifier = Modifier.width(70.dp),
            )
        }
    }
}
