package com.purplenexus.launcher.data

import android.content.ComponentName
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSession
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.app.NotificationManagerCompat
import kotlinx.coroutines.flow.MutableStateFlow

/**
 * Estado de reproducción tal como lo publica la sesión multimedia activa.
 * [positionMs] es la posición en el instante [updatedAt] (SystemClock.elapsedRealtime);
 * usa [positionNow] para obtener la posición extrapolada.
 */
data class MusicState(
    val title: String,
    val artist: String,
    val cover: ImageBitmap?,
    val positionMs: Long,
    val durationMs: Long,
    val playing: Boolean,
    val album: String = "",
    val pkg: String = "",
    val accent: Color? = null,
    val updatedAt: Long = SystemClock.elapsedRealtime(),
    val speed: Float = 1f,
) {
    /** Clave estable de la pista (no cambia con la posición ni con pausar/reanudar). */
    val trackKey: String get() = "$pkg|$title|$artist|$durationMs"

    fun positionNow(now: Long = SystemClock.elapsedRealtime()): Long {
        val p = if (playing) positionMs + ((now - updatedAt) * speed).toLong() else positionMs
        return if (durationMs > 0) p.coerceIn(0, durationMs) else p.coerceAtLeast(0)
    }
}

/**
 * Integración real con MediaSession/MediaController (Spotify y cualquier reproductor que publique sesión).
 *
 * Android solo entrega las sesiones de otras apps a quien tenga acceso a notificaciones, por eso existe
 * [NexusNotificationListener]: el usuario debe concederlo una vez en Ajustes. No se leen ni guardan notificaciones.
 * El enlace solo está activo mientras el launcher es visible (start/stop desde MainActivity).
 */
object MusicBridge {
    val state = MutableStateFlow<MusicState?>(null)
    /** true si el usuario concedió el acceso a notificaciones necesario para ver las sesiones. */
    val access = MutableStateFlow(false)

    private var appCtx: Context? = null
    private var manager: MediaSessionManager? = null
    private var controller: MediaController? = null
    private val main = Handler(Looper.getMainLooper())
    private var started = false

    // Caché de la portada/color para no recalcularlos en cada cambio de estado de reproducción.
    private var coverKey: String? = null
    private var coverCache: ImageBitmap? = null
    private var accentCache: Color? = null

    private val sessionsListener = MediaSessionManager.OnActiveSessionsChangedListener { list ->
        pick(list ?: emptyList())
    }

    private val callback = object : MediaController.Callback() {
        override fun onPlaybackStateChanged(state: PlaybackState?) { publish() }
        override fun onMetadataChanged(metadata: MediaMetadata?) { publish() }
        override fun onSessionDestroyed() { refresh() }
    }

    fun init(context: Context) {
        if (appCtx == null) appCtx = context.applicationContext
    }

    fun hasAccess(): Boolean {
        val c = appCtx ?: return false
        return NotificationManagerCompat.getEnabledListenerPackages(c).contains(c.packageName)
    }

    fun start() {
        val c = appCtx ?: return
        if (started) { refresh(); return }
        access.value = hasAccess()
        if (!access.value) { state.value = null; return }
        try {
            val m = c.getSystemService(Context.MEDIA_SESSION_SERVICE) as MediaSessionManager
            manager = m
            m.addOnActiveSessionsChangedListener(sessionsListener, component(c), main)
            started = true
            pick(m.getActiveSessions(component(c)))
        } catch (_: SecurityException) {
            access.value = false
            state.value = null
        }
    }

    fun stop() {
        if (!started) return
        runCatching { manager?.removeOnActiveSessionsChangedListener(sessionsListener) }
        runCatching { controller?.unregisterCallback(callback) }
        controller = null
        manager = null
        started = false
    }

    /** Vuelve a leer las sesiones (p. ej. al volver de Ajustes tras conceder el permiso). */
    fun refresh() {
        val c = appCtx ?: return
        access.value = hasAccess()
        if (!access.value) { stop(); state.value = null; return }
        if (!started) { start(); return }
        try { pick(manager?.getActiveSessions(component(c)) ?: emptyList()) } catch (_: SecurityException) {
            access.value = false; stop(); state.value = null
        }
    }

    private fun component(c: Context) = ComponentName(c, NexusNotificationListener::class.java)

    private fun pick(list: List<MediaController>) {
        // Prioridad: la que está sonando; si no, la sesión de mayor prioridad que tenga metadatos.
        val chosen = list.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING }
            ?: list.firstOrNull { it.metadata != null }
        if (chosen?.sessionToken != controller?.sessionToken) {
            runCatching { controller?.unregisterCallback(callback) }
            controller = chosen
            chosen?.registerCallback(callback, main)
        }
        publish()
    }

    private fun publish() {
        val c = controller
        val md = c?.metadata
        val ps = c?.playbackState
        if (c == null || md == null) { state.value = null; return }
        val st = ps?.state ?: PlaybackState.STATE_NONE
        if (st == PlaybackState.STATE_NONE || st == PlaybackState.STATE_STOPPED) { state.value = null; return }

        val title = md.getString(MediaMetadata.METADATA_KEY_TITLE)
            ?: md.getString(MediaMetadata.METADATA_KEY_DISPLAY_TITLE) ?: return run { state.value = null }
        val artist = md.getString(MediaMetadata.METADATA_KEY_ARTIST)
            ?: md.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST)
            ?: md.getString(MediaMetadata.METADATA_KEY_DISPLAY_SUBTITLE) ?: ""
        val album = md.getString(MediaMetadata.METADATA_KEY_ALBUM) ?: ""
        val duration = md.getLong(MediaMetadata.METADATA_KEY_DURATION)

        val key = "${c.packageName}|$title|$artist|$duration"
        if (key != coverKey) {
            coverKey = key
            val bmp = loadCover(md)
            coverCache = bmp?.let { scaled(it).asImageBitmap() }
            accentCache = bmp?.let { dominantColor(it) }
        }

        state.value = MusicState(
            title = title, artist = artist, album = album,
            cover = coverCache, accent = accentCache, pkg = c.packageName,
            positionMs = ps?.position?.takeIf { it >= 0 } ?: 0L,
            durationMs = duration.coerceAtLeast(0),
            playing = st == PlaybackState.STATE_PLAYING,
            updatedAt = ps?.lastPositionUpdateTime?.takeIf { it > 0 } ?: SystemClock.elapsedRealtime(),
            speed = ps?.playbackSpeed?.takeIf { it > 0f } ?: 1f,
        )
    }

    private fun loadCover(md: MediaMetadata): Bitmap? {
        listOf(MediaMetadata.METADATA_KEY_ALBUM_ART, MediaMetadata.METADATA_KEY_ART, MediaMetadata.METADATA_KEY_DISPLAY_ICON)
            .forEach { k -> md.getBitmap(k)?.let { return it } }
        // Algunas apps solo publican una URI; solo se leen content:// y file:// (nunca red).
        val ctx = appCtx ?: return null
        listOf(MediaMetadata.METADATA_KEY_ALBUM_ART_URI, MediaMetadata.METADATA_KEY_ART_URI, MediaMetadata.METADATA_KEY_DISPLAY_ICON_URI)
            .forEach { k ->
                val u = md.getString(k)?.let { runCatching { Uri.parse(it) }.getOrNull() } ?: return@forEach
                if (u.scheme == "content" || u.scheme == "file") {
                    runCatching {
                        ctx.contentResolver.openInputStream(u)?.use { BitmapFactory.decodeStream(it) }
                    }.getOrNull()?.let { return it }
                }
            }
        return null
    }

    /** Limita la portada a 512 px de lado mayor para no gastar RAM. */
    private fun scaled(b: Bitmap): Bitmap {
        val m = maxOf(b.width, b.height)
        if (m <= 512) return b
        val f = 512f / m
        return Bitmap.createScaledBitmap(b, (b.width * f).toInt().coerceAtLeast(1), (b.height * f).toInt().coerceAtLeast(1), true)
    }

    /** Color dominante: promedio ponderado por saturación, ignorando píxeles casi negros/blancos. */
    private fun dominantColor(b: Bitmap): Color? = runCatching {
        val s = Bitmap.createScaledBitmap(b, 24, 24, true)
        var r = 0f; var g = 0f; var bl = 0f; var wSum = 0f
        val hsv = FloatArray(3)
        for (y in 0 until s.height) for (x in 0 until s.width) {
            val px = s.getPixel(x, y)
            android.graphics.Color.colorToHSV(px, hsv)
            if (hsv[2] < 0.18f || (hsv[1] < 0.12f && hsv[2] > 0.9f)) continue
            val w = 0.15f + hsv[1] * hsv[2]
            r += android.graphics.Color.red(px) * w
            g += android.graphics.Color.green(px) * w
            bl += android.graphics.Color.blue(px) * w
            wSum += w
        }
        if (wSum <= 0f) null else {
            val out = floatArrayOf(0f, 0f, 0f)
            android.graphics.Color.colorToHSV(
                android.graphics.Color.rgb((r / wSum).toInt(), (g / wSum).toInt(), (bl / wSum).toInt()), out,
            )
            // Asegura que el color sea legible sobre fondo oscuro.
            out[1] = out[1].coerceAtLeast(0.35f); out[2] = out[2].coerceIn(0.65f, 1f)
            Color(android.graphics.Color.HSVToColor(out))
        }
    }.getOrNull()

    // ----- Controles de transporte (se ejecutan sobre la sesión de la app que suena) -----
    fun toggle() { controller?.let { c ->
        if (c.playbackState?.state == PlaybackState.STATE_PLAYING) c.transportControls.pause() else c.transportControls.play()
    } }
    fun next() { controller?.transportControls?.skipToNext() }
    fun prev() { controller?.transportControls?.skipToPrevious() }
    fun seekToFraction(f: Float) {
        val s = state.value ?: return
        if (s.durationMs > 0) controller?.transportControls?.seekTo((s.durationMs * f.coerceIn(0f, 1f)).toLong())
    }
}
