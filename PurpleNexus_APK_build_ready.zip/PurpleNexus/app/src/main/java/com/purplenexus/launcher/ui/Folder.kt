package com.purplenexus.launcher.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.purplenexus.launcher.data.AppInfo
import com.purplenexus.launcher.theme.LocalSettings
import com.purplenexus.launcher.theme.Nexus
import com.purplenexus.launcher.theme.palette

/** Carpeta como pequeño panel de cristal con vista previa 2x2. */
@Composable
fun FolderTile(apps: List<AppInfo>, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val p = LocalSettings.current.palette
    val tapSound = rememberTapSound()
    Column(modifier.tap { tapSound(); onClick() }, horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.size(72.dp).glass(Nexus.Tile, ornate = true, sweep = true).padding(9.dp), contentAlignment = Alignment.Center) {
            if (apps.isEmpty()) {
                GlyphIcon(Glyph.STAR, p.lavender.copy(alpha = 0.6f), 26.dp)
            } else {
                val minis = apps.take(4)
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    minis.chunked(2).forEach { row ->
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            row.forEach { Image(it.icon, null, Modifier.size(22.dp)) }
                        }
                    }
                }
            }
        }
        Spacer(Modifier.height(4.dp))
        Text("Carpeta", color = Nexus.White, fontSize = 11.sp, textAlign = TextAlign.Center)
    }
}

@Composable
fun FolderOverlay(
    visible: Boolean,
    apps: List<AppInfo>,
    onLaunch: (AppInfo) -> Unit,
    onRemove: (AppInfo) -> Unit,
    onClose: () -> Unit,
) {
    val p = LocalSettings.current.palette
    AnimatedVisibility(
        visible = visible,
        enter = fadeIn() + scaleIn(initialScale = 0.8f),
        exit = fadeOut() + scaleOut(targetScale = 0.9f),
    ) {
        Box(
            Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.5f)).tap(onClose),
            contentAlignment = Alignment.Center,
        ) {
            Column(
                Modifier
                    .padding(24.dp)
                    .background(p.bgTop.copy(alpha = 0.85f), Nexus.Card)
                    .glass(Nexus.Card, ornate = true, sweep = true)
                    .tap { }
                    .padding(22.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Text("Carpeta", color = Nexus.White, fontSize = 18.sp)
                Spacer(Modifier.height(6.dp))
                OrnamentDivider(width = 140.dp)
                Spacer(Modifier.height(10.dp))
                if (apps.isEmpty()) {
                    Text(
                        "Vacía. Mantén pulsada una app en el cajón y elige «Añadir a la carpeta».",
                        color = p.lavender, fontSize = 13.sp, textAlign = TextAlign.Center,
                    )
                } else {
                    apps.chunked(3).forEach { row ->
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            row.forEach { app ->
                                AppIcon(app, onClick = { onLaunch(app) }, onLongClick = { onRemove(app) })
                            }
                        }
                    }
                    Spacer(Modifier.height(6.dp))
                    Text("Mantén pulsada una app para sacarla", color = p.lavender.copy(alpha = 0.7f), fontSize = 11.sp)
                }
            }
        }
    }
}
