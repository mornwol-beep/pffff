package com.purplenexus.launcher.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.purplenexus.launcher.theme.LocalSettings
import com.purplenexus.launcher.theme.Nexus
import com.purplenexus.launcher.theme.palette
import kotlinx.coroutines.delay

/** Marca para mostrar la bienvenida una sola vez por proceso. */
object WelcomeState { var shown = false }

@Composable
fun WelcomeOverlay(onFinished: () -> Unit) {
    val p = LocalSettings.current.palette
    val appear = remember { Animatable(0f) }
    val out = remember { Animatable(1f) }
    LaunchedEffect(Unit) {
        appear.animateTo(1f, tween(900))
        delay(450)
        out.animateTo(0f, tween(700))
        onFinished()
    }
    Box(
        Modifier.fillMaxSize().graphicsLayer { alpha = out.value }.background(p.bgTop),
        contentAlignment = Alignment.Center,
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Box(Modifier.graphicsLayer { scaleX = 0.6f + 0.4f * appear.value; scaleY = 0.6f + 0.4f * appear.value; alpha = appear.value }) {
                GlyphIcon(Glyph.STAR, p.pearl, 64.dp)
            }
            Spacer(Modifier.height(18.dp))
            Text(
                "PURPLE NEXUS", color = Nexus.White, fontSize = 22.sp, letterSpacing = 6.sp, fontWeight = FontWeight.Light,
                modifier = Modifier.graphicsLayer { alpha = appear.value },
            )
            Spacer(Modifier.height(10.dp))
            OrnamentDivider(Modifier.graphicsLayer { alpha = appear.value }, 160.dp)
        }
    }
}
