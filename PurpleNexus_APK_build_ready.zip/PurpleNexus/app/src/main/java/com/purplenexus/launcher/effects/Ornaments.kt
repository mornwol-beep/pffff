package com.purplenexus.launcher.effects

import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke

/** Esquinas ornamentales: ángulo fino con rombo, en las cuatro esquinas del área de dibujo. */
fun DrawScope.cornerOrnaments(color: Color, inset: Float, len: Float) {
    val w = size.width
    val h = size.height
    ornamentCorner(color, inset, inset, 1f, 1f, len)
    ornamentCorner(color, w - inset, inset, -1f, 1f, len)
    ornamentCorner(color, inset, h - inset, 1f, -1f, len)
    ornamentCorner(color, w - inset, h - inset, -1f, -1f, len)
}

private fun DrawScope.ornamentCorner(color: Color, cx: Float, cy: Float, sx: Float, sy: Float, len: Float) {
    val path = Path().apply {
        moveTo(cx + sx * len, cy)
        lineTo(cx, cy)
        lineTo(cx, cy + sy * len)
    }
    drawPath(path, color, style = Stroke(width = 1.2f * density, cap = StrokeCap.Round))
    val d = len * 0.14f
    val dx = cx + sx * len * 0.36f
    val dy = cy + sy * len * 0.36f
    val diamond = Path().apply {
        moveTo(dx, dy - d)
        lineTo(dx + d, dy)
        lineTo(dx, dy + d)
        lineTo(dx - d, dy)
        close()
    }
    drawPath(diamond, color)
    drawLine(
        color.copy(alpha = color.alpha * 0.55f),
        Offset(cx + sx * len * 0.55f, cy + sy * len * 0.16f),
        Offset(cx + sx * len * 0.9f, cy + sy * len * 0.16f),
        strokeWidth = 1f * density,
    )
    drawLine(
        color.copy(alpha = color.alpha * 0.55f),
        Offset(cx + sx * len * 0.16f, cy + sy * len * 0.55f),
        Offset(cx + sx * len * 0.16f, cy + sy * len * 0.9f),
        strokeWidth = 1f * density,
    )
}

/** Destello de cuatro puntas. */
fun DrawScope.sparkle(center: Offset, r: Float, color: Color) {
    drawLine(color, Offset(center.x - r, center.y), Offset(center.x + r, center.y), strokeWidth = 1.2f * density, cap = StrokeCap.Round)
    drawLine(color, Offset(center.x, center.y - r), Offset(center.x, center.y + r), strokeWidth = 1.2f * density, cap = StrokeCap.Round)
    drawCircle(color, r * 0.18f, center)
}
